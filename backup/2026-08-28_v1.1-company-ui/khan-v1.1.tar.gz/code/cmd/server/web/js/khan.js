/* ============================================================
   خان — Application logic (Vue 3, Composition-free Options API
   for readability). All data below is mock/demo data intended
   to illustrate the UI; wire it to the Go backend endpoints
   documented in the design brief.
   ============================================================ */

const I18N = {
  fa: {
    tagline: 'فضای امن گفتگوی تیم شما',
    toggleTheme: 'تغییر حالت روشن/تیره',
    firstRun: 'اولین راه‌اندازی سیستم',
    companyName: 'نام شرکت', companyNamePh: 'مثلاً شرکت آریانا',
    adminUsername: 'نام کاربری ادمین', usernamePh: 'نام کاربری',
    displayName: 'نام نمایشی', displayNamePh: 'نام و نام خانوادگی',
    password: 'رمز عبور', username: 'نام کاربری',
    createWorkspace: 'ایجاد فضای کاری', login: 'ورود',
    firstTimeQ: 'اولین بار است از خان استفاده می‌کنید؟', setupLink: 'راه‌اندازی سیستم',
    haveAccountQ: 'قبلاً حساب ساخته‌اید؟', backToLogin: 'بازگشت به ورود',
    freeUpTo: 'رایگان برای شرکت‌های زیر ۲۰ نفر',
    searchChats: 'جستجوی گفتگوها…',
    tabChats: 'چت‌ها', tabRooms: 'اتاق‌ها', tabSearch: 'جستجو', tabUsers: 'کاربران',
    noChats: 'گفتگویی یافت نشد', noDept: 'بدون دپارتمان',
    newRoom: 'اتاق جدید', globalSearchPh: 'جستجو در همه پیام‌ها…',
    noResults: 'نتیجه‌ای یافت نشد', typeToSearch: 'برای جستجو تایپ کنید',
    online: 'آنلاین', offline: 'آفلاین',
    adminPanel: 'پنل مدیریت', logout: 'خروج',
    welcomeTitle: 'به خان خوش آمدید', welcomeSub: 'از لیست کنار، یک گفتگو را باز کنید',
    openSidebar: 'نمایش گفتگوها',
    pinnedMsgs: 'پیام پین‌شده', urgentBanner: 'این گفتگو حاوی یک پیام فوری است',
    isTyping: 'در حال تایپ است', edited: '(ویرایش‌شده)',
    replyingTo: 'در پاسخ به', dropFiles: 'فایل را اینجا رها کنید',
    typeMessage: 'پیامی بنویسید…', members: 'اعضا', addMember: 'افزودن عضو…',
    roomName: 'نام اتاق', roomNamePh: 'مثلاً تیم فروش', roomType: 'نوع اتاق',
    department: 'دپارتمان', cancel: 'انصراف', create: 'ایجاد',
    newUser: 'کاربر جدید', role: 'نقش', newDept: 'دپارتمان جدید', deptName: 'نام دپارتمان',
    newPoll: 'نظرسنجی جدید', question: 'سوال', questionPh: 'سوال نظرسنجی را بنویسید',
    option: 'گزینه', addOption: 'افزودن گزینه', publish: 'انتشار',
    forwardMsg: 'فوروارد پیام', reply: 'پاسخ', forward: 'فوروارد', pin: 'پین کردن',
    unpin: 'برداشتن پین', markUrgent: 'علامت‌گذاری فوری', edit: 'ویرایش', delete: 'حذف',
    atUsers: 'کاربران', atLicense: 'لایسنس', atNetwork: 'شبکه', atBackup: 'بکاپ',
    atLogs: 'لاگ‌ها', atDepts: 'دپارتمان‌ها', usersOf: 'کاربر فعال',
    colName: 'نام', colRole: 'نقش', colStatus: 'وضعیت', active: 'فعال', inactive: 'غیرفعال',
    exportExcel: 'خروجی اکسل', exported: 'فایل اکسل آماده دانلود شد',
    licenseDesc: 'وضعیت و مدیریت لایسنس نرم‌افزار', activeUsers: 'کاربران فعال',
    licenseStatus: 'وضعیت لایسنس', licenseActive: 'فعال', expiresOn: 'تاریخ انقضا',
    uploadKey: 'آپلود فایل لایسنس', uploadKeySub: 'فایل .key رمزنگاری‌شده',
    chooseFile: 'انتخاب فایل', keyUploaded: 'فایل لایسنس با موفقیت اعمال شد',
    networkDesc: 'تنظیمات سرور و هویت سازمانی', serverAddr: 'آدرس سرور', port: 'پورت',
    version: 'نسخه نرم‌افزار', companyLogo: 'لوگوی شرکت', orgColor: 'رنگ سازمانی',
    upload: 'آپلود', saveChanges: 'ذخیره تغییرات', saved: 'تغییرات ذخیره شد',
    backupDesc: 'پشتیبان‌گیری و بازیابی اطلاعات', backupNow: 'بکاپ فوری',
    downloaded: 'دانلود آغاز شد', restored: 'بازیابی با موفقیت انجام شد',
    logsDesc: 'رویدادهای اخیر سرور', refresh: 'بروزرسانی', logsRefreshed: 'لاگ‌ها بروزرسانی شد',
    deptsDesc: 'مدیریت دپارتمان‌های سازمان', rooms: 'اتاق',
    roleAdmin: 'ادمین', roleManager: 'مدیر', roleSupervisor: 'سوپروایزر', roleUser: 'کاربر عادی',
  },
  en: {
    tagline: "Your team's secure conversation space",
    toggleTheme: 'Toggle light/dark',
    firstRun: 'First-time system setup',
    companyName: 'Company name', companyNamePh: 'e.g. Ariana Co.',
    adminUsername: 'Admin username', usernamePh: 'Username',
    displayName: 'Display name', displayNamePh: 'Full name',
    password: 'Password', username: 'Username',
    createWorkspace: 'Create workspace', login: 'Sign in',
    firstTimeQ: 'First time using Khan?', setupLink: 'Set up system',
    haveAccountQ: 'Already have an account?', backToLogin: 'Back to sign in',
    freeUpTo: 'Free for companies under 20 people',
    searchChats: 'Search chats…',
    tabChats: 'Chats', tabRooms: 'Rooms', tabSearch: 'Search', tabUsers: 'Users',
    noChats: 'No chats found', noDept: 'No department',
    newRoom: 'New room', globalSearchPh: 'Search all messages…',
    noResults: 'No results found', typeToSearch: 'Type to search',
    online: 'Online', offline: 'Offline',
    adminPanel: 'Admin panel', logout: 'Log out',
    welcomeTitle: 'Welcome to Khan', welcomeSub: 'Open a conversation from the list',
    openSidebar: 'Show conversations',
    pinnedMsgs: 'pinned message', urgentBanner: 'This conversation has an urgent message',
    isTyping: 'is typing', edited: '(edited)',
    replyingTo: 'Replying to', dropFiles: 'Drop file here',
    typeMessage: 'Type a message…', members: 'Members', addMember: 'Add member…',
    roomName: 'Room name', roomNamePh: 'e.g. Sales team', roomType: 'Room type',
    department: 'Department', cancel: 'Cancel', create: 'Create',
    newUser: 'New user', role: 'Role', newDept: 'New department', deptName: 'Department name',
    newPoll: 'New poll', question: 'Question', questionPh: 'Write the poll question',
    option: 'Option', addOption: 'Add option', publish: 'Publish',
    forwardMsg: 'Forward message', reply: 'Reply', forward: 'Forward', pin: 'Pin',
    unpin: 'Unpin', markUrgent: 'Mark urgent', edit: 'Edit', delete: 'Delete',
    atUsers: 'Users', atLicense: 'License', atNetwork: 'Network', atBackup: 'Backup',
    atLogs: 'Logs', atDepts: 'Departments', usersOf: 'active users',
    colName: 'Name', colRole: 'Role', colStatus: 'Status', active: 'Active', inactive: 'Inactive',
    exportExcel: 'Export Excel', exported: 'Excel file ready for download',
    licenseDesc: 'Software license status and management', activeUsers: 'Active users',
    licenseStatus: 'License status', licenseActive: 'Active', expiresOn: 'Expires on',
    uploadKey: 'Upload license file', uploadKeySub: 'Encrypted .key file',
    chooseFile: 'Choose file', keyUploaded: 'License file applied successfully',
    networkDesc: 'Server settings and organization identity', serverAddr: 'Server address', port: 'Port',
    version: 'Software version', companyLogo: 'Company logo', orgColor: 'Organization color',
    upload: 'Upload', saveChanges: 'Save changes', saved: 'Changes saved',
    backupDesc: 'Backup and restore data', backupNow: 'Backup now',
    downloaded: 'Download started', restored: 'Restored successfully',
    logsDesc: 'Recent server events', refresh: 'Refresh', logsRefreshed: 'Logs refreshed',
    deptsDesc: 'Manage organization departments', rooms: 'rooms',
    roleAdmin: 'Admin', roleManager: 'Manager', roleSupervisor: 'Supervisor', roleUser: 'User',
  }
};

const THEME_COLORS = [
  { id: 'khan',     swatch: '#e8a33d', label: { fa: 'خان (طلایی)', en: 'Khan (gold)' } },
  { id: 'sapphire', swatch: '#3b82f6', label: { fa: 'یاقوت‌کبود (آبی)', en: 'Sapphire' } },
  { id: 'spring',   swatch: '#10b981', label: { fa: 'بهار (سبز)', en: 'Spring' } },
  { id: 'night',    swatch: '#8b5cf6', label: { fa: 'شب (بنفش)', en: 'Night' } },
  { id: 'sunset',   swatch: '#f97316', label: { fa: 'غروب (نارنجی)', en: 'Sunset' } },
  { id: 'frost',    swatch: '#64748b', label: { fa: 'یخبندان (خاکستری)', en: 'Frost' } },
];

function uid(prefix) { return prefix + '_' + Math.random().toString(36).slice(2, 9); }
function faTime(h, m) { return String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0'); }

const { createApp } = Vue;

createApp({
  template: document.getElementById('app-template').innerHTML,

  data() {
    return {
      locale: 'fa',
      themeMode: 'dark',
      themeColor: 'khan',
      themeColors: THEME_COLORS,

      screen: 'login', // login | app
      needsSetup: false,
      loginForm: { username: '', password: '' },
      setupForm: { company: '', username: '', displayName: '', password: '' },

      isMobile: window.innerWidth < 768,
      sidebarOpen: window.innerWidth >= 768,
      infoPanelOpen: false,
      sidebarTab: 'chats',
      chatSearch: '',
      globalSearch: '',
      chatHeaderSearchOpen: false,
      collapsedDepts: {},

      currentUser: { id: 'u1', name: 'آرمین رادفر', role: 'admin', color: '#e8a33d', online: true },

      departments: ['فروش', 'پشتیبانی', 'فناوری اطلاعات', 'مدیریت'],

      users: [
        { id: 'u1', name: 'آرمین رادفر', role: 'admin', color: '#e8a33d', online: true, active: true },
        { id: 'u2', name: 'سارا محمدی', role: 'manager', color: '#3b82f6', online: true, active: true },
        { id: 'u3', name: 'رضا کریمی', role: 'supervisor', color: '#10b981', online: false, active: true },
        { id: 'u4', name: 'نگار حسینی', role: 'user', color: '#8b5cf6', online: true, active: true },
        { id: 'u5', name: 'محمد امیری', role: 'user', color: '#f97316', online: false, active: true },
        { id: 'u6', name: 'الهام صادقی', role: 'user', color: '#64748b', online: true, active: false },
        { id: 'u7', name: 'کیان یوسفی', role: 'supervisor', color: '#e8a33d', online: false, active: true },
      ],

      rooms: [],
      messagesByRoom: {},
      activeRoomId: null,

      composerText: '',
      replyingTo: null,
      dragOver: false,

      showCreateRoom: false, showCreateUser: false, showCreateDept: false, showPoll: false, showForward: false,
      newRoom: { name: '', type: 'group', department: '' },
      newUser: { username: '', displayName: '', password: '', role: 'user' },
      newDeptName: '',
      poll: { question: '', options: ['', ''] },
      forwardMsg: null,
      memberToAdd: '',

      adminOpen: false, adminTab: 'users', adminNavOpen: false,
      company: { name: 'شرکت آریانا صنعت', serverAddr: '192.168.1.14', port: '1717', version: '1.1.0', userLimit: 20 },
      backups: [
        { id: 'b1', name: 'backup-1404-05-06.khb', date: '۱۴۰۴/۰۵/۰۶ — ۰۲:۰۰', size: '18.4 MB' },
        { id: 'b2', name: 'backup-1404-05-05.khb', date: '۱۴۰۴/۰۵/۰۵ — ۰۲:۰۰', size: '18.1 MB' },
        { id: 'b3', name: 'backup-1404-05-04.khb', date: '۱۴۰۴/۰۵/۰۴ — ۰۲:۰۰', size: '17.9 MB' },
      ],
      serverLogs: [
        { id: 1, time: '11:42:03', level: 'ok',   msg: 'server started on :1717' },
        { id: 2, time: '11:42:04', level: 'info', msg: 'websocket hub ready, 0 clients' },
        { id: 3, time: '11:44:12', level: 'info', msg: 'user "u2" authenticated' },
        { id: 4, time: '11:50:31', level: 'warn', msg: 'upload exceeded soft size hint (14MB)' },
        { id: 5, time: '12:02:09', level: 'info', msg: 'backup job completed in 3.2s' },
        { id: 6, time: '12:15:44', level: 'err',  msg: 'failed login attempt for "unknown_user"' },
      ],

      ctxMenu: { show: false, x: 0, y: 0, msg: null },
      toastMsg: '',
      roomTypes: ['group', 'public', 'private', 'channel'],
    };
  },

  computed: {
    dir() { return this.locale === 'fa' ? 'rtl' : 'ltr'; },
    theme() { return this.themeColor + '-' + this.themeMode; },
    activeRoom() { return this.rooms.find(r => r.id === this.activeRoomId) || null; },

    groupedChats() {
      const q = this.chatSearch.trim();
      const list = this.rooms.filter(r => !q || r.name.includes(q));
      const withDept = {};
      list.forEach(r => {
        const key = r.department || (this.locale === 'fa' ? 'مکالمات مستقیم' : 'Direct messages');
        (withDept[key] = withDept[key] || []).push(r);
      });
      return Object.keys(withDept).map(dept => ({ dept, rooms: withDept[dept] }));
    },

    messageGroups() {
      if (!this.activeRoom) return [];
      const msgs = this.messagesByRoom[this.activeRoom.id] || [];
      const groups = [];
      let lastDate = null, lastSender = null;
      msgs.forEach((m, i) => {
        if (m.date !== lastDate) { groups.push({ date: m.date, msgs: [] }); lastDate = m.date; lastSender = null; }
        m.showAvatar = m.senderName !== lastSender;
        m.showName = m.senderName !== lastSender;
        lastSender = m.senderName;
        groups[groups.length - 1].msgs.push(m);
      });
      return groups;
    },

    searchResults() {
      const q = this.globalSearch.trim();
      if (!q) return [];
      const out = [];
      Object.keys(this.messagesByRoom).forEach(rid => {
        this.messagesByRoom[rid].forEach(m => { if (m.text && m.text.includes(q)) out.push({ ...m, roomId: rid }); });
      });
      return out;
    },
  },

  watch: {
    dir(v) { document.documentElement.setAttribute('dir', v); document.documentElement.setAttribute('lang', this.locale); },
  },

  methods: {
    t(key) { return (I18N[this.locale] && I18N[this.locale][key]) || key; },
    initials(name) { return (name || '').trim().split(' ').slice(0,2).map(w => w[0]).join(''); },
    avatarStyle(color) { return color ? { background: `linear-gradient(145deg, ${color}, ${color}cc)` } : {}; },
    roleLabel(role) { return this.t('role' + role.charAt(0).toUpperCase() + role.slice(1)); },
    roomTypeLabel(ty) {
      const map = { fa: { group: 'گروه', public: 'عمومی', private: 'خصوصی', channel: 'کانال', dm: 'گفتگوی خصوصی' },
                    en: { group: 'Group', public: 'Public', private: 'Private', channel: 'Channel', dm: 'Direct message' } };
      return map[this.locale][ty] || ty;
    },
    roomName(id) { const r = this.rooms.find(r => r.id === id); return r ? r.name : ''; },
    roomOnlineCount(room) { return this.roomMembers(room).filter(u => u.online).length; },
    roomMembers(room) { return (room.members || []).map(id => this.users.find(u => u.id === id)).filter(Boolean); },
    nonMembers(room) { return this.users.filter(u => !(room.members || []).includes(u.id)); },
    pinnedCount(room) { return (room.pinned || []).length; },

    toggleMode() { this.themeMode = this.themeMode === 'dark' ? 'light' : 'dark'; },
    toggleDeptCollapse(dept) { this.collapsedDepts[dept] = !this.collapsedDepts[dept]; },

    toast(msg) { this.toastMsg = msg; clearTimeout(this._toastTimer); this._toastTimer = setTimeout(() => this.toastMsg = '', 2600); },

    doLogin() { this.screen = 'app'; this.seedData(); },
    doSetup() {
      this.company.name = this.setupForm.company || this.company.name;
      this.currentUser.name = this.setupForm.displayName || this.currentUser.name;
      this.needsSetup = false;
      this.screen = 'app';
      this.seedData();
    },
    logout() { this.screen = 'login'; this.activeRoomId = null; this.adminOpen = false; },

    openRoom(id) {
      this.activeRoomId = id;
      const r = this.rooms.find(r => r.id === id);
      if (r) r.unread = 0;
      if (this.isMobile) this.sidebarOpen = false;
      this.infoPanelOpen = false;
      this.$nextTick(this.scrollToBottom);
    },
    openDM(user) {
      let room = this.rooms.find(r => r.type === 'dm' && r.dmWith === user.id);
      if (!room) {
        room = { id: uid('room'), name: user.name, type: 'dm', dmWith: user.id, color: user.color,
                 department: null, members: [this.currentUser.id, user.id], online: user.online,
                 lastMsg: '', lastTime: '', unread: 0, pinned: [] };
        this.rooms.unshift(room);
        this.messagesByRoom[room.id] = [];
      }
      this.sidebarTab = 'chats';
      this.openRoom(room.id);
    },

    openAdmin() { this.adminOpen = true; this.adminTab = 'users'; },

    autoGrow(e) { const el = e.target; el.style.height = 'auto'; el.style.height = Math.min(el.scrollHeight, 140) + 'px'; },

    sendMessage() {
      if (!this.composerText.trim() || !this.activeRoom) return;
      const now = new Date();
      const msg = {
        id: uid('m'), mine: true, senderName: this.currentUser.name, color: this.currentUser.color,
        text: this.composerText.trim(), time: faTime(now.getHours(), now.getMinutes()),
        date: this.t('online') === 'آنلاین' ? 'امروز' : 'Today',
        reactions: [], replyTo: this.replyingTo ? { senderName: this.replyingTo.senderName, text: this.replyingTo.text } : null,
      };
      (this.messagesByRoom[this.activeRoom.id] = this.messagesByRoom[this.activeRoom.id] || []).push(msg);
      this.activeRoom.lastMsg = msg.text; this.activeRoom.lastTime = msg.time;
      this.composerText = ''; this.replyingTo = null;
      this.$nextTick(() => { this.scrollToBottom(); this.$refs.composerInput && (this.$refs.composerInput.style.height = 'auto'); });
      // demo auto-reply
      if (!this.activeRoom.dmWith) return;
      this.activeRoom.typingUser = this.roomName(this.activeRoom.id);
      setTimeout(() => {
        this.activeRoom.typingUser = null;
        const reply = { id: uid('m'), mine: false, senderName: this.activeRoom.name, color: this.activeRoom.color,
          text: this.locale === 'fa' ? 'دریافت شد، بررسی می‌کنم و خبر می‌دهم.' : 'Got it, I will check and let you know.',
          time: faTime(now.getHours(), now.getMinutes()+1), date: msg.date, reactions: [] };
        this.messagesByRoom[this.activeRoom.id].push(reply);
        this.$nextTick(this.scrollToBottom);
      }, 1600);
    },
    scrollToBottom() { const el = this.$refs.msgList; if (el) el.scrollTop = el.scrollHeight; },
    mockAttach() { this.toast(this.locale === 'fa' ? 'انتخاب فایل (نمایشی)' : 'File picker (demo)'); },
    onDrop() { this.dragOver = false; this.toast(this.locale === 'fa' ? 'فایل بارگذاری شد (نمایشی)' : 'File uploaded (demo)'); },

    startReply(m) { this.replyingTo = m; this.$refs.composerInput && this.$refs.composerInput.focus(); },
    startEdit(m) { m.editing = true; m.editDraft = m.text; },
    saveEdit(m) { m.text = m.editDraft; m.editing = false; m.edited = true; },
    deleteMessage(m) {
      const arr = this.messagesByRoom[this.activeRoom.id];
      const i = arr.indexOf(m); if (i > -1) arr.splice(i, 1);
    },
    quickReact(m, emoji) { this.toggleReaction(m, emoji); },
    toggleReaction(m, emoji) {
      m.reactions = m.reactions || [];
      let rx = m.reactions.find(r => r.emoji === emoji);
      if (rx) { rx.byMe ? (rx.count--, rx.byMe = false) : (rx.count++, rx.byMe = true); if (rx.count <= 0) m.reactions.splice(m.reactions.indexOf(rx),1); }
      else m.reactions.push({ emoji, count: 1, byMe: true });
    },
    togglePin(m) {
      if (!m) return;
      const room = this.activeRoom; room.pinned = room.pinned || [];
      const idx = room.pinned.findIndex(p => p.id === m.id);
      if (idx > -1) { room.pinned.splice(idx, 1); m.pinned = false; }
      else { room.pinned.push({ id: m.id, senderName: m.senderName, text: m.text }); m.pinned = true; }
    },
    markUrgent() { if (this.activeRoom) { this.activeRoom.urgent = true; this.toast(this.locale === 'fa' ? 'پیام به عنوان فوری علامت‌گذاری شد' : 'Marked as urgent'); } },
    openContextMenu(e, m) { this.ctxMenu = { show: true, x: e.clientX, y: e.clientY, msg: m }; },

    forwardTo(room) {
      if (!this.forwardMsg) return;
      const msg = { ...this.forwardMsg, id: uid('m'), mine: room.id === this.activeRoomId };
      (this.messagesByRoom[room.id] = this.messagesByRoom[room.id] || []).push(msg);
      this.showForward = false; this.forwardMsg = null;
      this.toast(this.locale === 'fa' ? 'پیام فوروارد شد' : 'Message forwarded');
    },

    addMember(room) {
      if (!this.memberToAdd) return;
      room.members = room.members || []; room.members.push(this.memberToAdd);
      this.memberToAdd = '';
      this.toast(this.locale === 'fa' ? 'عضو اضافه شد' : 'Member added');
    },
    removeMember(room, u) {
      room.members = (room.members || []).filter(id => id !== u.id);
      this.toast(this.locale === 'fa' ? 'عضو حذف شد' : 'Member removed');
    },

    createRoom() {
      if (!this.newRoom.name.trim()) return;
      const room = { id: uid('room'), name: this.newRoom.name.trim(), type: this.newRoom.type,
        department: this.newRoom.department || null, color: THEME_COLORS[Math.floor(Math.random()*6)].swatch,
        icon: '🏠', members: [this.currentUser.id], lastMsg: '', lastTime: '', unread: 0, pinned: [] };
      this.rooms.unshift(room); this.messagesByRoom[room.id] = [];
      this.showCreateRoom = false; this.newRoom = { name: '', type: 'group', department: '' };
      this.sidebarTab = 'chats'; this.openRoom(room.id);
    },
    createUser() {
      if (!this.newUser.username.trim() || !this.newUser.displayName.trim()) return;
      this.users.push({ id: uid('u'), name: this.newUser.displayName.trim(), role: this.newUser.role,
        color: THEME_COLORS[Math.floor(Math.random()*6)].swatch, online: false, active: true });
      this.showCreateUser = false; this.newUser = { username: '', displayName: '', password: '', role: 'user' };
      this.toast(this.locale === 'fa' ? 'کاربر ایجاد شد' : 'User created');
    },
    resetPassword(u) { this.toast((this.locale === 'fa' ? 'رمز عبور ' : 'Password reset for ') + u.name); },
    deleteUser(u) { this.users = this.users.filter(x => x.id !== u.id); },
    createDept() {
      if (!this.newDeptName.trim()) return;
      this.departments.push(this.newDeptName.trim());
      this.showCreateDept = false; this.newDeptName = '';
    },
    deleteDept(d) { this.departments = this.departments.filter(x => x !== d); },
    createPoll() {
      if (!this.poll.question.trim() || !this.activeRoom) return;
      const opts = this.poll.options.filter(o => o.trim());
      const now = new Date();
      const msg = { id: uid('m'), mine: true, senderName: this.currentUser.name, color: this.currentUser.color,
        text: '📊 ' + this.poll.question + '\n' + opts.map((o,i)=>`${i+1}. ${o}`).join('  '),
        time: faTime(now.getHours(), now.getMinutes()), date: 'امروز', reactions: [] };
      (this.messagesByRoom[this.activeRoom.id] = this.messagesByRoom[this.activeRoom.id] || []).push(msg);
      this.showPoll = false; this.poll = { question: '', options: ['', ''] };
      this.$nextTick(this.scrollToBottom);
    },
    createBackup() {
      const now = new Date();
      this.backups.unshift({ id: uid('b'), name: `backup-manual-${now.getHours()}${now.getMinutes()}.khb`, date: this.locale==='fa'?'اکنون':'Just now', size: '18.6 MB' });
      this.toast(this.locale === 'fa' ? 'بکاپ فوری ایجاد شد' : 'Backup created');
    },

    seedData() {
      if (this.rooms.length) return; // already seeded
      const rooms = [
        { id: 'r1', name: 'اتاق عمومی', type: 'public', department: 'مدیریت', icon: '📢', color: '#e8a33d',
          members: ['u1','u2','u3','u4','u5','u6','u7'], unread: 2, pinned: [], lastTime: '۱۰:۴۲' },
        { id: 'r2', name: 'تیم فروش', type: 'group', department: 'فروش', icon: '💼', color: '#3b82f6',
          members: ['u1','u2','u5'], unread: 0, pinned: [], urgent: true, lastTime: '۰۹:۵۵' },
        { id: 'r3', name: 'پشتیبانی مشتریان', type: 'group', department: 'پشتیبانی', icon: '🎧', color: '#10b981',
          members: ['u1','u3','u6'], unread: 5, pinned: [], lastTime: '۰۸:۲۰' },
        { id: 'r4', name: 'زیرساخت و DevOps', type: 'channel', department: 'فناوری اطلاعات', icon: '🛠️', color: '#8b5cf6',
          members: ['u1','u7'], unread: 0, pinned: [], lastTime: 'دیروز' },
        { id: 'r5', name: 'سارا محمدی', type: 'dm', dmWith: 'u2', department: null, color: '#3b82f6',
          members: ['u1','u2'], online: true, unread: 1, pinned: [], lastTime: '۱۱:۰۲' },
        { id: 'r6', name: 'رضا کریمی', type: 'dm', dmWith: 'u3', department: null, color: '#10b981',
          members: ['u1','u3'], online: false, unread: 0, pinned: [], lastTime: 'دیروز' },
      ];
      rooms.forEach(r => { r.lastMsg = ''; });
      this.rooms = rooms;

      this.messagesByRoom = {
        r1: [
          { id:'m1', mine:false, senderName:'سارا محمدی', color:'#3b82f6', text:'سلام به همه، صبح بخیر ☀️', time:'۰۸:۳۰', date:'امروز', reactions:[{emoji:'👍',count:3,byMe:false}] },
          { id:'m2', mine:false, senderName:'رضا کریمی', color:'#10b981', text:'صبح بخیر، جلسه امروز ساعت ۱۱ برگزار میشه یادتون باشه', time:'۰۸:۳۲', date:'امروز', reactions:[] , pinned:true},
          { id:'m3', mine:true, senderName:'آرمین رادفر', color:'#e8a33d', text:'ممنون رضا جان، من دعوت‌نامه رو الان می‌فرستم', time:'۰۸:۳۵', date:'امروز', reactions:[] },
          { id:'m4', mine:false, senderName:'نگار حسینی', color:'#8b5cf6', text:'گزارش فروش هفته گذشته رو ضمیمه کردم', time:'۱۰:۴۰', date:'امروز', reactions:[],
            attachment:{ icon:'📄', name:'گزارش-فروش-هفته۱۸.pdf' } },
          { id:'m5', mine:false, senderName:'نگار حسینی', color:'#8b5cf6', text:'اگه سوالی بود در خدمتم', time:'۱۰:۴۲', date:'امروز', reactions:[{emoji:'❤️',count:1,byMe:false}] },
        ],
        r2: [
          { id:'m6', mine:false, senderName:'محمد امیری', color:'#f97316', text:'مشتری جدید از اصفهان تماس گرفته، نیاز به پیگیری فوری داره', time:'۰۹:۵۰', date:'امروز', reactions:[] },
          { id:'m7', mine:true, senderName:'آرمین رادفر', color:'#e8a33d', text:'باشه، شماره‌شو برام بفرست تماس می‌گیرم', time:'۰۹:۵۳', date:'امروز', reactions:[],
            replyTo:{ senderName:'محمد امیری', text:'مشتری جدید از اصفهان تماس گرفته...' } },
          { id:'m8', mine:false, senderName:'محمد امیری', color:'#f97316', text:'۰۹۱۳xxxxxxx — آقای رستمی', time:'۰۹:۵۵', date:'امروز', reactions:[] },
        ],
        r3: [
          { id:'m9', mine:false, senderName:'الهام صادقی', color:'#64748b', text:'تیکت شماره ۴۴۲ هنوز بازه، کسی رسیدگی کرده؟', time:'۰۸:۱۰', date:'امروز', reactions:[] },
          { id:'m10', mine:false, senderName:'رضا کریمی', color:'#10b981', text:'من دارم روش کار می‌کنم', time:'۰۸:۲۰', date:'امروز', reactions:[{emoji:'👍',count:1,byMe:true}] },
        ],
        r4: [
          { id:'m11', mine:false, senderName:'کیان یوسفی', color:'#e8a33d', text:'بکاپ شب گذشته با موفقیت انجام شد ✅', time:'۰۲:۰۰', date:'دیروز', reactions:[] },
        ],
        r5: [
          { id:'m12', mine:false, senderName:'سارا محمدی', color:'#3b82f6', text:'آرمین جان وقت داری یه لحظه صحبت کنیم؟', time:'۱۱:۰۰', date:'امروز', reactions:[] },
        ],
        r6: [
          { id:'m13', mine:true, senderName:'آرمین رادفر', color:'#e8a33d', text:'گزارش رو دیدم، عالی بود مرسی', time:'۱۸:۱۰', date:'دیروز', reactions:[] },
        ],
      };
      // hydrate pinned lists from flagged messages
      this.rooms.forEach(r => {
        r.pinned = (this.messagesByRoom[r.id] || []).filter(m => m.pinned).map(m => ({ id:m.id, senderName:m.senderName, text:m.text }));
      });
    },
  },

  mounted() {
    document.documentElement.setAttribute('dir', this.dir);
    document.documentElement.setAttribute('lang', this.locale);
    window.addEventListener('resize', () => { this.isMobile = window.innerWidth < 768; if (!this.isMobile) this.sidebarOpen = true; });
    window.addEventListener('click', (e) => { if (this.ctxMenu.show && !e.target.closest('.context-menu')) this.ctxMenu.show = false; });
    // demo: after a short delay, show a typing indicator in the sales room to prove liveliness
    setTimeout(() => { const r = this.rooms.find(r => r.id === 'r2'); if (r) r.typingUser = 'محمد امیری'; }, 4000);
    setTimeout(() => { const r = this.rooms.find(r => r.id === 'r2'); if (r) r.typingUser = null; }, 7000);
  },
}).mount('#app');
