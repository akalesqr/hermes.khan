/* ============================================================
   خان — Application logic (Vue 3, connected to Go backend)
   Real API integration for all features
   ============================================================ */

const I18N = {
  fa: {
    tagline: 'فضای امن گفتگوی تیم شما',
    toggleTheme: 'تغییر حالت روشن/تیره',
    firstRun: 'اولین راه‌اندازی سیستم',
    companyName: 'نام شرکت', companyNamePh: 'مثلاً شرکت آریانا',
    adminUsername: 'نام کاربری ادمین', usernamePh: 'نام کاربری',
    displayName: 'نام نمایشی', displayNamePh: 'نام و نام خانوادگی',
    password: 'رمز عبور', username: 'نام کاربری',
    createWorkspace: 'ایجاد فضای کاری', login: 'ورود',
    firstTimeQ: 'اولین بار است از خان استفاده می‌کنید؟', setupLink: 'راه‌اندازی سیستم',
    haveAccountQ: 'قبلاً حساب ساخته‌اید؟', backToLogin: 'بازگشت به ورود',
    freeUpTo: 'رایگان برای شرکت‌های زیر ۲۰ نفر',
    searchChats: 'جستجوی گفتگوها…',
    tabChats: 'چت‌ها', tabRooms: 'اتاق‌ها', tabSearch: 'جستجو', tabUsers: 'کاربران',
    noChats: 'گفتگویی یافت نشد', noDept: 'بدون دپارتمان',
    newRoom: 'اتاق جدید', globalSearchPh: 'جستجو در همه پیام‌ها…',
    noResults: 'نتیجه‌ای یافت نشد', typeToSearch: 'برای جستجو تایپ کنید',
    online: 'آنلاین', offline: 'آفلاین',
    adminPanel: 'پنل مدیریت', logout: 'خروج',
    welcomeTitle: 'به خان خوش آمدید', welcomeSub: 'از لیست کنار، یک گفتگو را باز کنید',
    openSidebar: 'نمایش گفتگوها',
    pinnedMsgs: 'پیام پین‌شده', urgentBanner: 'این گفتگو حاوی یک پیام فوری است',
    isTyping: 'در حال تایپ است', edited: '(ویرایش‌شده)',
    replyingTo: 'در پاسخ به', dropFiles: 'فایل را اینجا رها کنید',
    typeMessage: 'پیامی بنویسید…', members: 'اعضا', addMember: 'افزودن عضو…',
    roomName: 'نام اتاق', roomNamePh: 'مثلاً تیم فروش', roomType: 'نوع اتاق',
    department: 'دپارتمان', cancel: 'انصراف', create: 'ایجاد',
    newUser: 'کاربر جدید', role: 'نقش', newDept: 'دپارتمان جدید', deptName: 'نام دپارتمان',
    newPoll: 'نظرسنجی جدید', question: 'سوال', questionPh: 'سوال نظرسنجی را بنویسید',
    option: 'گزینه', addOption: 'افزودن گزینه', publish: 'انتشار',
    forwardMsg: 'فوروارد پیام', reply: 'پاسخ', forward: 'فوروارد', pin: 'پین کردن',
    unpin: 'برداشتن پین', markUrgent: 'علامت‌گذاری فوری', edit: 'ویرایش', delete: 'حذف',
    atUsers: 'کاربران', atLicense: 'لایسنس', atNetwork: 'شبکه', atBackup: 'بکاپ',
    atLogs: 'لاگ‌ها', atDepts: 'دپارتمان‌ها', usersOf: 'کاربر فعال',
    colName: 'نام', colRole: 'نقش', colStatus: 'وضعیت', active: 'فعال', inactive: 'غیرفعال',
    exportExcel: 'خروجی اکسل', exported: 'فایل اکسل آماده دانلود شد',
    licenseDesc: 'وضعیت و مدیریت لایسنس نرم‌افزار', activeUsers: 'کاربران فعال',
    licenseStatus: 'وضعیت لایسنس', licenseActive: 'فعال', expiresOn: 'تاریخ انقضا',
    uploadKey: 'آپلود فایل لایسنس', uploadKeySub: 'فایل .key رمزنگاری‌شده',
    chooseFile: 'انتخاب فایل', keyUploaded: 'فایل لایسنس با موفقیت اعمال شد',
    networkDesc: 'تنظیمات سرور و هویت سازمانی', serverAddr: 'آدرس سرور', port: 'پورت',
    version: 'نسخه نرم‌افزار', companyLogo: 'لوگوی شرکت', orgColor: 'رنگ سازمانی',
    upload: 'آپلود', saveChanges: 'ذخیره تغییرات', saved: 'تغییرات ذخیره شد',
    backupDesc: 'پشتیبان‌گیری و بازیابی اطلاعات', backupNow: 'بکاپ فوری',
    downloaded: 'دانلود آغاز شد', restored: 'بازیابی با موفقیت انجام شد',
    logsDesc: 'رویدادهای اخیر سرور', refresh: 'بروزرسانی', logsRefreshed: 'لاگ‌ها بروزرسانی شد',
    deptsDesc: 'مدیریت دپارتمان‌های سازمان', rooms: 'اتاق',
    roleAdmin: 'ادمین', roleManager: 'مدیر', roleSupervisor: 'سوپروایزر', roleUser: 'کاربر عادی',
  },
  en: {
    tagline: "Your team's secure conversation space",
    toggleTheme: 'Toggle light/dark',
    firstRun: 'First-time system setup',
    companyName: 'Company name', companyNamePh: 'e.g. Ariana Co.',
    adminUsername: 'Admin username', usernamePh: 'Username',
    displayName: 'Display name', displayNamePh: 'Full name',
    password: 'Password', username: 'Username',
    createWorkspace: 'Create workspace', login: 'Sign in',
    firstTimeQ: 'First time using Khan?', setupLink: 'Set up system',
    haveAccountQ: 'Already have an account?', backToLogin: 'Back to sign in',
    freeUpTo: 'Free for companies under 20 people',
    searchChats: 'Search chats…',
    tabChats: 'Chats', tabRooms: 'Rooms', tabSearch: 'Search', tabUsers: 'Users',
    noChats: 'No chats found', noDept: 'No department',
    newRoom: 'New room', globalSearchPh: 'Search all messages…',
    noResults: 'No results found', typeToSearch: 'Type to search',
    online: 'Online', offline: 'Offline',
    adminPanel: 'Admin panel', logout: 'Log out',
    welcomeTitle: 'Welcome to Khan', welcomeSub: 'Open a conversation from the list',
    openSidebar: 'Show conversations',
    pinnedMsgs: 'pinned message', urgentBanner: 'This conversation has an urgent message',
    isTyping: 'is typing', edited: '(edited)',
    replyingTo: 'Replying to', dropFiles: 'Drop file here',
    typeMessage: 'Type a message…', members: 'Members', addMember: 'Add member…',
    roomName: 'Room name', roomNamePh: 'e.g. Sales team', roomType: 'Room type',
    department: 'Department', cancel: 'Cancel', create: 'Create',
    newUser: 'New user', role: 'Role', newDept: 'New department', deptName: 'Department name',
    newPoll: 'New poll', question: 'Question', questionPh: 'Write the poll question',
    option: 'Option', addOption: 'Add option', publish: 'Publish',
    forwardMsg: 'Forward message', reply: 'Reply', forward: 'Forward', pin: 'Pin',
    unpin: 'Unpin', markUrgent: 'Mark urgent', edit: 'Edit', delete: 'Delete',
    atUsers: 'Users', atLicense: 'License', atNetwork: 'Network', atBackup: 'Backup',
    atLogs: 'Logs', atDepts: 'Departments', usersOf: 'active users',
    colName: 'Name', colRole: 'Role', colStatus: 'Status', active: 'Active', inactive: 'Inactive',
    exportExcel: 'Export Excel', exported: 'Excel file ready for download',
    licenseDesc: 'Software license status and management', activeUsers: 'Active users',
    licenseStatus: 'License status', licenseActive: 'Active', expiresOn: 'Expires on',
    uploadKey: 'Upload license file', uploadKeySub: 'Encrypted .key file',
    chooseFile: 'Choose file', keyUploaded: 'License file applied successfully',
    networkDesc: 'Server settings and organization identity', serverAddr: 'Server address', port: 'Port',
    version: 'Software version', companyLogo: 'Company logo', orgColor: 'Organization color',
    upload: 'Upload', saveChanges: 'Save changes', saved: 'Changes saved',
    backupDesc: 'Backup and restore data', backupNow: 'Backup now',
    downloaded: 'Download started', restored: 'Restored successfully',
    logsDesc: 'Recent server events', refresh: 'Refresh', logsRefreshed: 'Logs refreshed',
    deptsDesc: 'Manage organization departments', rooms: 'rooms',
    roleAdmin: 'Admin', roleManager: 'Manager', roleSupervisor: 'Supervisor', roleUser: 'User',
  }
};

const THEME_COLORS = [
  { id: 'khan',     swatch: '#e8a33d', label: { fa: 'خان (طلایی)', en: 'Khan (gold)' } },
  { id: 'sapphire', swatch: '#3b82f6', label: { fa: 'یاقوت‌کبود (آبی)', en: 'Sapphire' } },
  { id: 'spring',   swatch: '#10b981', label: { fa: 'بهار (سبز)', en: 'Spring' } },
  { id: 'night',    swatch: '#8b5cf6', label: { fa: 'شب (بنفش)', en: 'Night' } },
  { id: 'sunset',   swatch: '#f97316', label: { fa: 'غروب (نارنجی)', en: 'Sunset' } },
  { id: 'frost',    swatch: '#64748b', label: { fa: 'یخبندان (خاکستری)', en: 'Frost' } },
];

function uid(prefix) { return prefix + '_' + Math.random().toString(36).slice(2, 9); }
function faTime(h, m) { return String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0'); }
function jTime(iso) { try { const d = new Date(iso); return faTime(d.getHours(), d.getMinutes()); } catch { return ''; } }
function faDate(iso) { try { const d = new Date(iso); return d.toLocaleDateString('fa-IR', { day: 'numeric', month: 'long' }); } catch { return ''; } }

const { createApp } = Vue;

createApp({
  template: document.getElementById('app-template').innerHTML,

  data() {
    return {
      locale: 'fa',
      themeMode: 'dark',
      themeColor: 'khan',
      themeColors: THEME_COLORS,

      screen: 'login',
      needsSetup: false,
      loginForm: { username: '', password: '' },
      setupForm: { company: '', username: '', displayName: '', password: '' },

      isMobile: window.innerWidth < 768,
      sidebarOpen: window.innerWidth >= 768,
      infoPanelOpen: false,
      sidebarTab: 'chats',
      chatSearch: '',
      globalSearch: '',
      chatHeaderSearchOpen: false,
      collapsedDepts: {},

      token: null,
      currentUser: null,
      users: [],
      rooms: [],
      departments: [],
      messagesByRoom: {},
      activeRoomId: null,
      unreadMap: {},

      composerText: '',
      replyingTo: null,
      dragOver: false,

      showCreateRoom: false, showCreateUser: false, showCreateDept: false, showPoll: false, showForward: false,
      newRoom: { name: '', type: 'group', department: '' },
      newUser: { username: '', displayName: '', password: '', role: 'user' },
      newDeptName: '',
      poll: { question: '', options: ['', ''] },
      forwardMsg: null,
      memberToAdd: '',

      adminOpen: false, adminTab: 'users', adminNavOpen: false,
      company: { name: '', serverAddr: '', port: '', version: '1.1.0', userLimit: 20 },
      backups: [],
      serverLogs: [],

      ctxMenu: { show: false, x: 0, y: 0, msg: null },
      toastMsg: '',
      roomTypes: ['group', 'public', 'private', 'channel'],
    };
  },

  computed: {
    dir() { return this.locale === 'fa' ? 'rtl' : 'ltr'; },
    theme() { return this.themeColor + '-' + this.themeMode; },
    activeRoom() { return this.rooms.find(r => r.id === this.activeRoomId) || null; },

    groupedChats() {
      const q = this.chatSearch.trim();
      const list = this.rooms.filter(r => !q || r.name.includes(q));
      const withDept = {};
      list.forEach(r => {
        const key = r.department || (this.locale === 'fa' ? 'مکالمات مستقیم' : 'Direct messages');
        (withDept[key] = withDept[key] || []).push(r);
      });
      return Object.keys(withDept).map(dept => ({ dept, rooms: withDept[dept] }));
    },

    messageGroups() {
      if (!this.activeRoom) return [];
      const msgs = this.messagesByRoom[this.activeRoom.id] || [];
      const groups = [];
      let lastDate = null, lastSender = null;
      msgs.forEach((m, i) => {
        if (m.date !== lastDate) { groups.push({ date: m.date, msgs: [] }); lastDate = m.date; lastSender = null; }
        m.showAvatar = m.senderName !== lastSender;
        m.showName = m.senderName !== lastSender;
        lastSender = m.senderName;
        groups[groups.length - 1].msgs.push(m);
      });
      return groups;
    },

    searchResults() {
      const q = this.globalSearch.trim();
      if (!q) return [];
      const out = [];
      Object.keys(this.messagesByRoom).forEach(rid => {
        this.messagesByRoom[rid].forEach(m => { if (m.text && m.text.includes(q)) out.push({ ...m, roomId: rid }); });
      });
      return out;
    },
  },

  watch: {
    dir(v) { document.documentElement.setAttribute('dir', v); document.documentElement.setAttribute('lang', this.locale); },
    theme(v) { document.documentElement.setAttribute('data-theme', v); },
    themeMode(v) { document.documentElement.setAttribute('data-theme', this.themeColor + '-' + v); },
    themeColor(v) { document.documentElement.setAttribute('data-theme', v + '-' + this.themeMode); },
  },

  methods: {
    t(key) { return (I18N[this.locale] && I18N[this.locale][key]) || key; },
    initials(name) { return (name || '').trim().split(' ').slice(0,2).map(w => w[0]).join(''); },
    avatarStyle(color) { return color ? { background: `linear-gradient(145deg, ${color}, ${color}cc)` } : {}; },
    roleLabel(role) { return this.t('role' + role.charAt(0).toUpperCase() + role.slice(1)); },
    roomTypeLabel(ty) {
      const map = { fa: { group: 'گروه', public: 'عمومی', private: 'خصوصی', channel: 'کانال', dm: 'گفتگوی خصوصی' },
                    en: { group: 'Group', public: 'Public', private: 'Private', channel: 'Channel', dm: 'Direct message' } };
      return map[this.locale][ty] || ty;
    },
    roomName(id) { const r = this.rooms.find(r => r.id === id); return r ? r.name : ''; },
    roomOnlineCount(room) { return this.roomMembers(room).filter(u => u.online).length; },
    roomMembers(room) { return (room.members || []).map(id => this.users.find(u => u.id === id)).filter(Boolean); },
    nonMembers(room) { return this.users.filter(u => !(room.members || []).includes(u.id)); },
    pinnedCount(room) { return (room.pinned || []).length; },

    toggleMode() { this.themeMode = this.themeMode === 'dark' ? 'light' : 'dark'; },
    toggleDeptCollapse(dept) { this.collapsedDepts[dept] = !this.collapsedDepts[dept]; },

    toast(msg) { this.toastMsg = msg; clearTimeout(this._toastTimer); this._toastTimer = setTimeout(() => this.toastMsg = '', 2600); },

    // ============ AUTH & SETUP ============
    async doLogin() {
      try {
        const res = await this.api('/api/auth/login', { method: 'POST', body: this.loginForm });
        if (res.token) {
          this.token = res.token;
          this.currentUser = res.user;
          localStorage.setItem('khan_token', this.token);
          this.screen = 'app';
          await this.loadAll();
        }
      } catch (e) { this.toast(e.message || this.t('login')); }
    },

    async doSetup() {
      try {
        await this.api('/api/setup', {
          method: 'POST',
          body: { admin_username: this.setupForm.username, admin_password: this.setupForm.password, company_name: this.setupForm.company }
        });
        this.needsSetup = false;
        // auto login after setup
        await this.doLogin();
      } catch (e) { this.toast(e.message || this.t('createWorkspace')); }
    },

    async loadSession() {
      const saved = localStorage.getItem('khan_token');
      if (!saved) return;
      this.token = saved;
      try {
        const user = await this.api('/api/auth/me');
        this.currentUser = user;
        this.screen = 'app';
        await this.loadAll();
      } catch (e) {
        localStorage.removeItem('khan_token');
        this.token = null;
        this.screen = 'login';
      }
    },

    logout() {
      this.api('/api/auth/logout', { method: 'POST' }).catch(() => {});
      localStorage.removeItem('khan_token');
      this.token = null;
      this.currentUser = null;
      this.rooms = [];
      this.messagesByRoom = {};
      this.activeRoomId = null;
      this.screen = 'login';
    },

    // ============ API HELPER ============
    async api(path, opts = {}) {
      const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
      if (this.token) headers['Authorization'] = 'Bearer ' + this.token;
      const res = await fetch(path, { ...opts, headers, credentials: 'same-origin' });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'خطای سرور');
      return data;
    },

    // ============ DATA LOADING ============
    async loadAll() {
      try {
        const [users, rooms] = await Promise.all([
          this.api('/api/users'),
          this.api('/api/rooms')
        ]);
        this.users = Array.isArray(users) ? users : [];
        this.rooms = Array.isArray(rooms) ? rooms : [];
        this.unreadMap = JSON.parse(localStorage.getItem('khan_readmap') || '{}');
        // Load messages for all rooms in background
        this.rooms.forEach(r => this.loadMessages(r.id).catch(() => {}));
        this.loadRoomsDiscovery();
        this.loadDepartments();
        this.loadPinned();
        // Auto-open first room
        if (!this.activeRoomId && this.rooms.length) {
          this.openRoom(this.rooms[0]);
        }
        // Load company name
        const company = await this.api('/api/settings/company');
        this.company.name = company.company_name || '';
        // Connect WebSocket
        this.connectWS();
      } catch (e) { console.error('loadAll error:', e); }
    },

    async loadRoomsDiscovery() {
      try {
        const [pub, priv] = await Promise.all([
          this.api('/api/rooms/public'),
          this.api('/api/rooms/private')
        ]);
        const existing = new Set(this.rooms.map(r => r.id));
        [...(Array.isArray(pub) ? pub : []), ...(Array.isArray(priv) ? priv : [])].forEach(r => {
          if (!existing.has(r.id)) { this.rooms.push(r); existing.add(r.id); }
        });
      } catch (e) { console.error('loadRoomsDiscovery:', e); }
    },

    async loadDepartments() {
      try {
        this.departments = await this.api('/api/departments') || [];
      } catch (e) { console.error('loadDepartments:', e); }
    },

    async loadMessages(roomId) {
      try {
        const msgs = await this.api('/api/messages/' + roomId);
        this.messagesByRoom[roomId] = Array.isArray(msgs) ? msgs.map(m => ({
          ...m,
          time: jTime(m.created_at),
          date: faDate(m.created_at),
          reactions: (m.reactions || []).map(r => ({ emoji: r.emoji, count: r.count, byMe: r.by_me })),
          mine: m.sender_id === this.currentUser?.id,
        })) : [];
      } catch (e) { console.error('loadMessages:', e); }
    },

    async loadMembers(roomId) {
      try {
        const members = await this.api('/api/rooms/' + roomId + '/members');
        const room = this.rooms.find(r => r.id === roomId);
        if (room) room.members = Array.isArray(members) ? members.map(m => m.id) : [];
      } catch (e) { console.error('loadMembers:', e); }
    },

    async loadPinned() {
      try {
        if (!this.activeRoom) return;
        const pins = await this.api('/api/messages/' + this.activeRoom.id + '/pins');
        this.activeRoom.pinned = Array.isArray(pins) ? pins : [];
      } catch (e) { console.error('loadPinned:', e); }
    },

    // ============ ROOMS ============
    openRoom(id) {
      this.activeRoomId = id;
      const r = this.rooms.find(r => r.id === id);
      if (r) { r.unread = 0; this.unreadMap[id] = 0; localStorage.setItem('khan_readmap', JSON.stringify(this.unreadMap)); }
      if (this.isMobile) this.sidebarOpen = false;
      this.infoPanelOpen = false;
      this.loadMessages(id);
      this.loadMembers(id);
      this.loadPinned();
      this.$nextTick(() => this.scrollToBottom());
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ type: 'mark_read', room_id: id, last_id: this.messagesByRoom[id]?.slice(-1)[0]?.id || 0 }));
      }
    },

    openDM(user) {
      let room = this.rooms.find(r => r.type === 'dm' && r.dm_with === user.id);
      if (!room) {
        room = { id: uid('room'), name: user.name, type: 'dm', dm_with: user.id, color: user.color,
          department: null, members: [this.currentUser.id, user.id], online: user.online,
          last_msg: '', last_time: '', unread: 0, pinned: [] };
        this.rooms.unshift(room);
        this.messagesByRoom[room.id] = [];
      }
      this.sidebarTab = 'chats';
      this.openRoom(room.id);
    },

    async createRoom() {
      if (!this.newRoom.name.trim()) return;
      try {
        const room = await this.api('/api/rooms', { method: 'POST', body: this.newRoom });
        this.rooms.unshift(room);
        this.messagesByRoom[room.id] = [];
        this.showCreateRoom = false;
        this.newRoom = { name: '', type: 'group', department: '' };
        this.sidebarTab = 'chats';
        this.openRoom(room.id);
      } catch (e) { this.toast(e.message); }
    },

    async joinRoom(room) {
      try {
        await this.api('/api/rooms/' + room.id + '/join', { method: 'POST' });
        await this.loadAll();
        const fresh = this.rooms.find(r => r.id === room.id);
        if (fresh) await this.openRoom(fresh);
      } catch (e) { this.toast(e.message); }
    },

    // ============ MESSAGES ============
    async sendMessage() {
      if (!this.composerText.trim() || !this.activeRoom) return;
      const text = this.composerText.trim();
      const replyTo = this.replyingTo ? this.replyingTo.id : null;
      try {
        const msg = await this.api('/api/messages/' + this.activeRoom.id, {
          method: 'POST',
          body: { text, reply_to: replyTo }
        });
        this.messagesByRoom[this.activeRoom.id] = this.messagesByRoom[this.activeRoom.id] || [];
        this.messagesByRoom[this.activeRoom.id].push({
          ...msg,
          time: jTime(msg.created_at),
          date: faDate(msg.created_at),
          mine: true,
          reactions: [],
        });
        this.activeRoom.last_msg = text;
        this.activeRoom.last_time = jTime(msg.created_at);
        this.composerText = '';
        this.replyingTo = null;
        this.$nextTick(() => { this.scrollToBottom(); this.$refs.composerInput && (this.$refs.composerInput.style.height = 'auto'); });
      } catch (e) { this.toast(e.message); }
    },

    scrollToBottom() { const el = this.$refs.msgList; if (el) el.scrollTop = el.scrollHeight; },
    mockAttach() { this.toast(this.locale === 'fa' ? 'انتخاب فایل (نیاز به پیاده‌سازی)' : 'File picker (TODO)'); },
    onDrop() { this.dragOver = false; this.toast(this.locale === 'fa' ? 'بارگذاری فایل (نیاز به پیاده‌سازی)' : 'File upload (TODO)'); },

    startReply(m) { this.replyingTo = m; this.$refs.composerInput && this.$refs.composerInput.focus(); },
    startEdit(m) { m.editing = true; m.editDraft = m.text; },
    async saveEdit(m) {
      try {
        await this.api('/api/messages/' + m.id + '/edit', { method: 'POST', body: { text: m.editDraft } });
        m.text = m.editDraft;
        m.editing = false;
        m.edited = true;
      } catch (e) { this.toast(e.message); }
    },
    async deleteMessage(m) {
      try {
        await this.api('/api/messages/' + m.id, { method: 'DELETE' });
        const arr = this.messagesByRoom[this.activeRoom.id];
        const i = arr.indexOf(m); if (i > -1) arr.splice(i, 1);
      } catch (e) { this.toast(e.message); }
    },

    quickReact(m, emoji) { this.toggleReaction(m, emoji); },
    async toggleReaction(m, emoji) {
      const existing = (m.reactions || []).find(r => r.emoji === emoji);
      if (existing) {
        if (existing.byMe) {
          m.reactions = m.reactions.filter(r => r !== existing);
          try { await this.api('/api/messages/' + m.id + '/reactions', { method: 'DELETE', body: { emoji } }); } catch {}
        } else {
          existing.count++; existing.byMe = true;
          try { await this.api('/api/messages/' + m.id + '/reactions', { method: 'POST', body: { emoji } }); } catch {}
        }
      } else {
        m.reactions = m.reactions || [];
        m.reactions.push({ emoji, count: 1, byMe: true });
        try { await this.api('/api/messages/' + m.id + '/reactions', { method: 'POST', body: { emoji } }); } catch {}
      }
    },

    async togglePin(m) {
      if (!m) return;
      const room = this.activeRoom; room.pinned = room.pinned || [];
      const idx = room.pinned.findIndex(p => p.id === m.id);
      if (idx > -1) { room.pinned.splice(idx, 1); m.pinned = false; }
      else { room.pinned.push({ id: m.id, senderName: m.senderName, text: m.text }); m.pinned = true; }
      try { await this.api('/api/messages/' + m.id + (m.pinned ? '/pin' : '/unpin'), { method: 'POST' }); } catch {}
    },

    markUrgent() { if (this.activeRoom) { this.activeRoom.urgent = true; this.toast(this.locale === 'fa' ? 'پیام به عنوان فوری علامت‌گذاری شد' : 'Marked as urgent'); } },

    openContextMenu(e, m) { this.ctxMenu = { show: true, x: e.clientX, y: e.clientY, msg: m }; },

    async forwardTo(room) {
      if (!this.forwardMsg) return;
      try {
        await this.api('/api/messages/' + this.forwardMsg.id + '/forward', { method: 'POST', body: { room_id: room.id } });
        this.showForward = false; this.forwardMsg = null;
        this.toast(this.locale === 'fa' ? 'پیام فوروارد شد' : 'Message forwarded');
      } catch (e) { this.toast(e.message); }
    },

    // ============ MEMBERS ============
    async addMember(room) {
      if (!this.memberToAdd) return;
      try {
        await this.api('/api/rooms/' + room.id + '/members', { method: 'POST', body: { user_id: this.memberToAdd } });
        room.members = room.members || []; room.members.push(this.memberToAdd);
        this.memberToAdd = '';
        this.toast(this.locale === 'fa' ? 'عضو اضافه شد' : 'Member added');
      } catch (e) { this.toast(e.message); }
    },
    async removeMember(room, u) {
      try {
        await this.api('/api/rooms/' + room.id + '/members/' + u.id, { method: 'DELETE' });
        room.members = (room.members || []).filter(id => id !== u.id);
        this.toast(this.locale === 'fa' ? 'عضو حذف شد' : 'Member removed');
      } catch (e) { this.toast(e.message); }
    },

    // ============ ADMIN ============
    async createUser() {
      if (!this.newUser.username.trim() || !this.newUser.displayName.trim()) return;
      try {
        await this.api('/api/users', { method: 'POST', body: this.newUser });
        this.showCreateUser = false;
        this.newUser = { username: '', displayName: '', password: '', role: 'user' };
        this.toast(this.locale === 'fa' ? 'کاربر ایجاد شد' : 'User created');
        this.loadAll();
      } catch (e) { this.toast(e.message); }
    },
    resetPassword(u) { this.toast((this.locale === 'fa' ? 'رمز عبور ' : 'Password reset for ') + u.name); },
    async deleteUser(u) {
      try {
        await this.api('/api/users/' + u.id, { method: 'DELETE' });
        this.users = this.users.filter(x => x.id !== u.id);
        this.toast(this.locale === 'fa' ? 'کاربر حذف شد' : 'User deleted');
      } catch (e) { this.toast(e.message); }
    },
    async createDept() {
      if (!this.newDeptName.trim()) return;
      try {
        await this.api('/api/departments', { method: 'POST', body: { name: this.newDeptName.trim() } });
        this.departments.push(this.newDeptName.trim());
        this.showCreateDept = false; this.newDeptName = '';
        this.toast(this.locale === 'fa' ? 'دپارتمان ایجاد شد' : 'Department created');
      } catch (e) { this.toast(e.message); }
    },
    async deleteDept(d) {
      try {
        await this.api('/api/departments/' + d, { method: 'DELETE' });
        this.departments = this.departments.filter(x => x !== d);
      } catch (e) { this.toast(e.message); }
    },
    async createPoll() {
      if (!this.poll.question.trim() || !this.activeRoom) return;
      const opts = this.poll.options.filter(o => o.trim());
      try {
        const msg = await this.api('/api/messages/' + this.activeRoom.id, {
          method: 'POST',
          body: { text: '📊 ' + this.poll.question + '\n' + opts.map((o,i)=>`${i+1}. ${o}`).join('  '), poll: { question: this.poll.question, options: opts } }
        });
        this.messagesByRoom[this.activeRoom.id].push({
          ...msg, time: jTime(msg.created_at), date: faDate(msg.created_at), mine: true, reactions: []
        });
        this.showPoll = false; this.poll = { question: '', options: ['', ''] };
        this.$nextTick(this.scrollToBottom);
      } catch (e) { this.toast(e.message); }
    },

    async createBackup() {
      try {
        await this.api('/api/settings/backup', { method: 'POST' });
        this.toast(this.locale === 'fa' ? 'بکاپ فوری ایجاد شد' : 'Backup created');
        this.loadBackups();
      } catch (e) { this.toast(e.message); }
    },
    async loadBackups() {
      try {
        this.backups = await this.api('/api/settings/backups') || [];
      } catch (e) { console.error('loadBackups:', e); }
    },
    async saveCompany() {
      try {
        await this.api('/api/settings/company', { method: 'POST', body: { company_name: this.company.name } });
        this.toast(this.t('saved'));
      } catch (e) { this.toast(e.message); }
    },

    // ============ WEBSOCKET ============
    connectWS() {
      if (!this.token) return;
      const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
      this.ws = new WebSocket(`${proto}//${location.host}/ws?token=${this.token}`);
      this.ws.onmessage = (ev) => {
        try {
          const msg = JSON.parse(ev.data);
          this.handleWS(msg);
        } catch (e) { console.error('WS parse:', e); }
      };
      this.ws.onclose = () => setTimeout(() => this.connectWS(), 5000);
    },
    handleWS(msg) {
      switch (msg.type) {
        case 'new_message':
          if (msg.room_id === this.activeRoomId) {
            this.messagesByRoom[msg.room_id] = this.messagesByRoom[msg.room_id] || [];
            this.messagesByRoom[msg.room_id].push({
              ...msg, time: jTime(msg.created_at), date: faDate(msg.created_at),
              mine: msg.sender_id === this.currentUser.id, reactions: []
            });
            this.$nextTick(this.scrollToBottom);
          } else {
            const room = this.rooms.find(r => r.id === msg.room_id);
            if (room) { room.unread = (room.unread || 0) + 1; this.unreadMap[msg.room_id] = room.unread; localStorage.setItem('khan_readmap', JSON.stringify(this.unreadMap)); }
          }
          break;
        case 'user_typing':
          if (msg.room_id === this.activeRoomId) this.activeRoom.typingUser = msg.user_name;
          break;
        case 'user_stop_typing':
          if (msg.room_id === this.activeRoomId) this.activeRoom.typingUser = null;
          break;
        case 'message_read':
          if (msg.room_id === this.activeRoomId) {
            this.messagesByRoom[msg.room_id]?.forEach(m => { if (m.id <= msg.last_id) m.read = true; });
          }
          break;
        case 'reaction':
          const roomMsgs = this.messagesByRoom[msg.room_id];
          if (roomMsgs) {
            const m = roomMsgs.find(x => x.id === msg.message_id);
            if (m) { let rx = m.reactions.find(r => r.emoji === msg.emoji); if (rx) { rx.count = msg.count; rx.byMe = msg.by_me; } else m.reactions.push({ emoji: msg.emoji, count: msg.count, byMe: msg.by_me }); }
          }
          break;
        case 'user_online':
          const u = this.users.find(x => x.id === msg.user_id); if (u) u.online = true;
          break;
        case 'user_offline':
          const u2 = this.users.find(x => x.id === msg.user_id); if (u2) u2.online = false;
          break;
      }
    },

    mounted() {
      document.documentElement.setAttribute('dir', this.dir);
      document.documentElement.setAttribute('lang', this.locale);
      document.documentElement.setAttribute('data-theme', this.themeColor + '-' + this.themeMode);
      window.addEventListener('resize', () => { this.isMobile = window.innerWidth < 768; if (!this.isMobile) this.sidebarOpen = true; });
      window.addEventListener('click', (e) => { if (this.ctxMenu.show && !e.target.closest('.context-menu')) this.ctxMenu.show = false; });
      this.loadSession();
      this.api('/api/setup/needs-setup').then(res => { this.needsSetup = res.needs_setup; });
    },
  },
}).mount('#app');