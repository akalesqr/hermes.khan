package database

import _ "embed"

//go:embed migrations/001_init.up.sql
var migrationUp string

//go:embed migrations/001_init.down.sql
var migrationDown string
