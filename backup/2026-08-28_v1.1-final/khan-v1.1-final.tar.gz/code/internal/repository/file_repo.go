package repository

import (
	"database/sql"
	"errors"
	"time"

	"khan/internal/database"
	"khan/internal/models"
)

// ErrNotFound is returned when a record doesn't exist
var ErrNotFound = errors.New("not found")

var errNotFound = ErrNotFound

// FileRepo handles file metadata persistence
type FileRepo struct {
	db *database.SQLiteDB
}

func NewFileRepo(db *database.SQLiteDB) *FileRepo { return &FileRepo{db: db} }

// Create inserts file metadata
func (r *FileRepo) Create(f *models.File) (int64, error) {
	now := f.CreatedAt.Format(time.RFC3339)
	res, err := r.db.Exec(
		`INSERT INTO files (owner_id, room_id, file_name, stored_as, size, mime_type, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)`,
		f.OwnerID, f.RoomID, f.FileName, f.StoredAs, f.Size, f.MimeType, now,
	)
	if err != nil {
		return 0, err
	}
	return res.LastInsertId()
}

// GetByID finds a file
func (r *FileRepo) GetByID(id int64) (*models.File, error) {
	row := r.db.QueryRow(
		`SELECT id, owner_id, room_id, file_name, stored_as, size, mime_type, created_at FROM files WHERE id = ?`, id,
	)
	f := &models.File{}
	var createdAt string
	err := row.Scan(&f.ID, &f.OwnerID, &f.RoomID, &f.FileName, &f.StoredAs, &f.Size, &f.MimeType, &createdAt)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, nil
		}
		return nil, err
	}
	if t, err := time.Parse(time.RFC3339, createdAt); err == nil {
		f.CreatedAt = t
	}
	return f, nil
}

// CanAccess checks if user has access to a file (member of its room)
func (r *FileRepo) CanAccess(fileID, userID int64) (bool, error) {
	var count int
	err := r.db.QueryRow(
		`SELECT COUNT(*) FROM room_members rm
		 INNER JOIN files f ON f.room_id = rm.room_id
		 WHERE f.id = ? AND rm.user_id = ?`, fileID, userID,
	).Scan(&count)
	return count > 0, err
}
