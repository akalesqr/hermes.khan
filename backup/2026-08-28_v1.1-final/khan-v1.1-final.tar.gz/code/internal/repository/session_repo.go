package repository

import (
	"database/sql"
	"time"

	"khan/internal/database"
	"khan/internal/models"
)

// SessionRepo handles session persistence
type SessionRepo struct {
	db *database.SQLiteDB
}

func NewSessionRepo(db *database.SQLiteDB) *SessionRepo { return &SessionRepo{db: db} }

// Create stores a new session token
func (r *SessionRepo) Create(s *models.Session) error {
	_, err := r.db.Exec(
		`INSERT INTO sessions (user_id, token, expires_at, created_at) VALUES (?, ?, ?, ?)`,
		s.UserID, s.Token,
		s.ExpiresAt.Format(time.RFC3339),
		s.CreatedAt.Format(time.RFC3339),
	)
	return err
}

// GetByToken finds a session by token
func (r *SessionRepo) GetByToken(token string) (*models.Session, error) {
	row := r.db.QueryRow(
		`SELECT id, user_id, token, expires_at, created_at FROM sessions WHERE token = ?`, token,
	)
	s := &models.Session{}
	var expiresAt, createdAt string
	err := row.Scan(&s.ID, &s.UserID, &s.Token, &expiresAt, &createdAt)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, ErrNotFound
		}
		return nil, err
	}
	if t, err := time.Parse(time.RFC3339, expiresAt); err == nil {
		s.ExpiresAt = t
	}
	if t, err := time.Parse(time.RFC3339, createdAt); err == nil {
		s.CreatedAt = t
	}
	return s, nil
}

// Delete removes a session (logout)
func (r *SessionRepo) Delete(token string) error {
	_, err := r.db.Exec(`DELETE FROM sessions WHERE token = ?`, token)
	return err
}

// DeleteForUser removes all sessions for a user (force logout)
func (r *SessionRepo) DeleteForUser(userID int64) error {
	_, err := r.db.Exec(`DELETE FROM sessions WHERE user_id = ?`, userID)
	return err
}

// CleanupExpired removes expired sessions
func (r *SessionRepo) CleanupExpired() error {
	now := time.Now().Format(time.RFC3339)
	_, err := r.db.Exec(`DELETE FROM sessions WHERE expires_at < ?`, now)
	return err
}
