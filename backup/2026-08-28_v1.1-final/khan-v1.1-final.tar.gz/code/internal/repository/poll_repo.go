package repository

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"time"

	"khan/internal/database"
	"khan/internal/models"
)

// PollRepo handles polls (نظرسنجی)
type PollRepo struct {
	db *database.SQLiteDB
}

func NewPollRepo(db *database.SQLiteDB) *PollRepo { return &PollRepo{db: db} }

// Create inserts a poll and returns its id
func (r *PollRepo) Create(roomID, creatorID int64, question string, options []string) (int64, error) {
	now := time.Now().Format(time.RFC3339)
	optionsJSON, _ := json.Marshal(options)
	res, err := r.db.Exec(
		`INSERT INTO polls (room_id, creator_id, question, options, created_at, closed) VALUES (?, ?, ?, ?, ?, 0)`,
		roomID, creatorID, question, string(optionsJSON), now,
	)
	if err != nil {
		return 0, fmt.Errorf("insert poll: %w", err)
	}
	return res.LastInsertId()
}

// GetByID returns a poll
func (r *PollRepo) GetByID(id int64) (*models.Poll, error) {
	row := r.db.QueryRow(
		`SELECT id, room_id, creator_id, question, options, created_at, closed, closed_at
		 FROM polls WHERE id = ?`, id,
	)
	p, err := scanPoll(row)
	if err != nil {
		return nil, err
	}
	if p == nil {
		return nil, nil
	}
	// Attach votes
	votes, err := r.listVotes(id)
	if err != nil {
		return nil, err
	}
	p.Votes = votes
	return p, nil
}

// Vote casts or changes a user's vote on a poll option
func (r *PollRepo) Vote(pollID, userID int64, option int) error {
	tx, err := r.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()

	// Validate poll exists + not closed
	var closed int
	var optionsJSON string
	err = tx.QueryRow(`SELECT closed, options FROM polls WHERE id = ?`, pollID).Scan(&closed, &optionsJSON)
	if err != nil {
		return err
	}
	if closed != 0 {
		return nil // poll is closed
	}

	var options []string
	if err := json.Unmarshal([]byte(optionsJSON), &options); err != nil {
		return err
	}
	if option < 0 || option >= len(options) {
		return nil // invalid option
	}

	// Remove existing vote
	if _, err := tx.Exec(`DELETE FROM poll_votes WHERE poll_id = ? AND user_id = ?`, pollID, userID); err != nil {
		return err
	}

	// Insert new vote
	now := time.Now().Format(time.RFC3339)
	if _, err := tx.Exec(
		`INSERT INTO poll_votes (poll_id, user_id, option, voted_at) VALUES (?, ?, ?, ?)`,
		pollID, userID, option, now,
	); err != nil {
		return err
	}

	return tx.Commit()
}

// Close closes a poll
func (r *PollRepo) Close(pollID int64) error {
	now := time.Now().Format(time.RFC3339)
	_, err := r.db.Exec(`UPDATE polls SET closed = 1, closed_at = ? WHERE id = ?`, now, pollID)
	return err
}

// ListByRoom returns polls in a room
func (r *PollRepo) ListByRoom(roomID int64) ([]models.Poll, error) {
	rows, err := r.db.Query(
		`SELECT id, room_id, creator_id, question, options, created_at, closed, closed_at
		 FROM polls WHERE room_id = ? ORDER BY id DESC`, roomID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var out []models.Poll
	for rows.Next() {
		p, err := scanPollFromScanner(rows)
		if err != nil {
			return nil, err
		}
		if p == nil {
			continue
		}
		votes, err := r.listVotes(p.ID)
		if err != nil {
			return nil, err
		}
		p.Votes = votes
		out = append(out, *p)
	}
	return out, rows.Err()
}

// --- helpers ---

// scannable is an interface satisfied by both *sql.Row and *sql.Rows
type scannable interface {
	Scan(dest ...any) error
}

func scanPollFromScanner(s scannable) (*models.Poll, error) {
	var p models.Poll
	var createdAt, closedAt, optionsJSON string
	var closed int
	err := s.Scan(
		&p.ID, &p.RoomID, &p.CreatorID, &p.Question, &optionsJSON,
		&createdAt, &closed, &closedAt,
	)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, nil
		}
		return nil, err
	}
	p.Closed = closed != 0
	if t, err := time.Parse(time.RFC3339, createdAt); err == nil {
		p.CreatedAt = t
	}
	if closedAt != "" {
		if t, err := time.Parse(time.RFC3339, closedAt); err == nil {
			p.ClosedAt = &t
		}
	}
	if err := json.Unmarshal([]byte(optionsJSON), &p.Options); err != nil {
		p.Options = []string{}
	}
	return &p, nil
}

func scanPoll(row *sql.Row) (*models.Poll, error) {
	return scanPollFromScanner(row)
}

func (r *PollRepo) listVotes(pollID int64) ([]models.PollVote, error) {
	rows, err := r.db.Query(
		`SELECT id, poll_id, user_id, option, voted_at FROM poll_votes WHERE poll_id = ?`, pollID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var votes []models.PollVote
	for rows.Next() {
		var v models.PollVote
		var votedAt string
		if err := rows.Scan(&v.ID, &v.PollID, &v.UserID, &v.Option, &votedAt); err != nil {
			return nil, err
		}
		if t, err := time.Parse(time.RFC3339, votedAt); err == nil {
			v.VotedAt = t
		}
		votes = append(votes, v)
	}
	return votes, rows.Err()
}
