package repository

import (
	"database/sql"
	"time"

	"khan/internal/database"
	"khan/internal/models"
)

// PinRepo handles pinned messages (پین پیام بالای اتاق)
type PinRepo struct {
	db *database.SQLiteDB
}

func NewPinRepo(db *database.SQLiteDB) *PinRepo { return &PinRepo{db: db} }

// Pin pins a message to the top of a room
func (p *PinRepo) Pin(roomID, messageID, userID int64) error {
	now := time.Now().Format(time.RFC3339)
	_, err := p.db.Exec(
		`INSERT OR IGNORE INTO pins (room_id, message_id, user_id, created_at) VALUES (?, ?, ?, ?)`,
		roomID, messageID, userID, now,
	)
	return err
}

// Unpin removes a pinned message
func (p *PinRepo) Unpin(roomID, messageID int64) error {
	_, err := p.db.Exec(`DELETE FROM pins WHERE room_id = ? AND message_id = ?`, roomID, messageID)
	return err
}

// ListForRoom returns pinned messages in a room
func (p *PinRepo) ListForRoom(roomID int64) ([]models.Pin, error) {
	rows, err := p.db.Query(
		`SELECT id, room_id, message_id, user_id, created_at FROM pins WHERE room_id = ?`, roomID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.Pin
	for rows.Next() {
		var pin models.Pin
		var createdAt string
		if err := rows.Scan(&pin.ID, &pin.RoomID, &pin.MessageID, &pin.UserID, &createdAt); err != nil {
			return nil, err
		}
		if t, err := time.Parse(time.RFC3339, createdAt); err == nil {
			pin.CreatedAt = t
		}
		out = append(out, pin)
	}
	return out, rows.Err()
}

// IsPinned checks if a message is pinned
func (p *PinRepo) IsPinned(messageID int64) bool {
	var count int
	err := p.db.QueryRow(
		`SELECT COUNT(*) FROM pins WHERE message_id = ?`, messageID,
	).Scan(&count)
	if err != nil {
		if err == sql.ErrNoRows {
			return false
		}
		return false
	}
	return count > 0
}
