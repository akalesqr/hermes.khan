package repository

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"khan/internal/database"
	"khan/internal/models"
)

// MessageRepo handles message persistence
type MessageRepo struct {
	db *database.SQLiteDB
}

func NewMessageRepo(db *database.SQLiteDB) *MessageRepo { return &MessageRepo{db: db} }

// Create inserts a message
func (r *MessageRepo) Create(m *models.Message) (int64, error) {
	now := m.CreatedAt.Format(time.RFC3339)
	var editedAt, deletedAt string
	if m.EditedAt != nil {
		editedAt = m.EditedAt.Format(time.RFC3339)
	}
	if m.DeletedAt != nil {
		deletedAt = m.DeletedAt.Format(time.RFC3339)
	}
	var mentionsJSON string
	if len(m.Mentions) > 0 {
		b, _ := json.Marshal(m.Mentions)
		mentionsJSON = string(b)
	} else {
		mentionsJSON = "[]"
	}

	res, err := r.db.Exec(
		`INSERT INTO messages (room_id, sender_id, body, file_id, created_at, edited_at, deleted_at, reply_to, forwarded_from, mentions, urgent, poll_id)
		 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		m.RoomID, m.SenderID, string(m.Body), m.FileID, now,
		editedAt, deletedAt, m.ReplyTo, m.Forwarded,
		mentionsJSON, btoi(m.Urgent), m.PollID,
	)
	if err != nil {
		return 0, fmt.Errorf("insert message: %w", err)
	}
	return res.LastInsertId()
}

// GetByID finds a message
func (r *MessageRepo) GetByID(id int64) (*models.Message, error) {
	row := r.db.QueryRow(
		`SELECT id, room_id, sender_id, body, file_id, created_at, edited_at, deleted_at, reply_to, forwarded_from, mentions, urgent, poll_id
		 FROM messages WHERE id = ?`, id,
	)
	return scanMessage(row)
}

// ListByRoom returns messages for a room, paginated (before cursor), newest last
func (r *MessageRepo) ListByRoom(roomID int64, before int64, limit int) ([]models.Message, error) {
	var rows *sql.Rows
	var err error
	if before > 0 {
		rows, err = r.db.Query(
			`SELECT id, room_id, sender_id, body, file_id, created_at, edited_at, deleted_at, reply_to, forwarded_from, mentions, urgent, poll_id
			 FROM messages WHERE room_id = ? AND deleted_at = '' AND id < ?
			 ORDER BY id DESC LIMIT ?`, roomID, before, limit,
		)
	} else {
		rows, err = r.db.Query(
			`SELECT id, room_id, sender_id, body, file_id, created_at, edited_at, deleted_at, reply_to, forwarded_from, mentions, urgent, poll_id
			 FROM messages WHERE room_id = ? AND deleted_at = ''
			 ORDER BY id DESC LIMIT ?`, roomID, limit,
		)
	}
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	msgs, err := scanMessages(rows)
	if err != nil {
		return nil, err
	}
	// Reverse to get oldest-first ordering
	for i, j := 0, len(msgs)-1; i < j; i, j = i+1, j-1 {
		msgs[i], msgs[j] = msgs[j], msgs[i]
	}
	return msgs, nil
}

// ListSince returns messages in a room after a message id (for live sync / offline)
func (r *MessageRepo) ListSince(roomID int64, afterID int64) ([]models.Message, error) {
	rows, err := r.db.Query(
		`SELECT id, room_id, sender_id, body, file_id, created_at, edited_at, deleted_at, reply_to, forwarded_from, mentions, urgent, poll_id
		 FROM messages WHERE room_id = ? AND deleted_at = '' AND id > ?
		 ORDER BY id ASC`, roomID, afterID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanMessages(rows)
}

// SearchMessages searches message text in a room (or all rooms the user can see)
func (r *MessageRepo) SearchMessages(roomIDs []int64, query string, limit int) ([]models.Message, error) {
	if len(roomIDs) == 0 {
		return nil, nil
	}
	q := "%" + strings.ToLower(strings.TrimSpace(query)) + "%"
	placeholders := make([]string, len(roomIDs))
	args := make([]interface{}, 0, len(roomIDs)+2)
	for i, id := range roomIDs {
		placeholders[i] = "?"
		args = append(args, id)
	}
	args = append(args, q, limit)

	querySQL := fmt.Sprintf(
		`SELECT id, room_id, sender_id, body, file_id, created_at, edited_at, deleted_at, reply_to, forwarded_from, mentions, urgent, poll_id
		 FROM messages WHERE deleted_at = '' AND room_id IN (%s) AND LOWER(body) LIKE ?
		 ORDER BY id DESC LIMIT ?`,
		strings.Join(placeholders, ","),
	)
	rows, err := r.db.Query(querySQL, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanMessages(rows)
}

// ListByRoomAll returns all non-deleted messages across the given rooms (newest first)
func (r *MessageRepo) ListByRoomAll(roomIDs []int64) ([]models.Message, error) {
	if len(roomIDs) == 0 {
		return nil, nil
	}
	placeholders := make([]string, len(roomIDs))
	args := make([]interface{}, 0, len(roomIDs))
	for i, id := range roomIDs {
		placeholders[i] = "?"
		args = append(args, id)
	}
	querySQL := fmt.Sprintf(
		`SELECT id, room_id, sender_id, body, file_id, created_at, edited_at, deleted_at, reply_to, forwarded_from, mentions, urgent, poll_id
		 FROM messages WHERE deleted_at = '' AND room_id IN (%s)
		 ORDER BY id DESC`,
		strings.Join(placeholders, ","),
	)
	rows, err := r.db.Query(querySQL, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanMessages(rows)
}

// UpdateBody updates message text (edit)
func (r *MessageRepo) UpdateBody(id int64, body []byte) error {
	now := time.Now().Format(time.RFC3339)
	_, err := r.db.Exec(
		`UPDATE messages SET body = ?, edited_at = ? WHERE id = ?`, string(body), now, id,
	)
	return err
}

// SoftDelete marks a message as deleted
func (r *MessageRepo) SoftDelete(id int64) error {
	now := time.Now().Format(time.RFC3339)
	_, err := r.db.Exec(`UPDATE messages SET deleted_at = ? WHERE id = ?`, now, id)
	return err
}

// ToggleUrgent flips the urgent flag
func (r *MessageRepo) ToggleUrgent(id int64, urgent bool) error {
	_, err := r.db.Exec(`UPDATE messages SET urgent = ? WHERE id = ?`, btoi(urgent), id)
	return err
}

// AddReaction inserts a reaction (idempotent per user+emoji)
func (r *MessageRepo) AddReaction(messageID, userID int64, emoji string) error {
	_, err := r.db.Exec(
		`INSERT OR IGNORE INTO reactions (message_id, user_id, emoji) VALUES (?, ?, ?)`,
		messageID, userID, emoji,
	)
	return err
}

// RemoveReaction deletes a reaction
func (r *MessageRepo) RemoveReaction(messageID, userID int64, emoji string) error {
	_, err := r.db.Exec(
		`DELETE FROM reactions WHERE message_id = ? AND user_id = ? AND emoji = ?`,
		messageID, userID, emoji,
	)
	return err
}

// ListReactions returns reactions for a message
func (r *MessageRepo) ListReactions(messageID int64) ([]models.Reaction, error) {
	rows, err := r.db.Query(
		`SELECT id, message_id, user_id, emoji FROM reactions WHERE message_id = ?`, messageID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var reacs []models.Reaction
	for rows.Next() {
		var re models.Reaction
		if err := rows.Scan(&re.ID, &re.MessageID, &re.UserID, &re.Emoji); err != nil {
			return nil, err
		}
		reacs = append(reacs, re)
	}
	return reacs, rows.Err()
}

// --- helpers ---

func scanMessage(row *sql.Row) (*models.Message, error) {
	var m models.Message
	var createdAt, editedAt, deletedAt string
	var mentionsJSON string
	var urgent int
	var body string
	err := row.Scan(
		&m.ID, &m.RoomID, &m.SenderID, &body, &m.FileID,
		&createdAt, &editedAt, &deletedAt,
		&m.ReplyTo, &m.Forwarded, &mentionsJSON, &urgent, &m.PollID,
	)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, nil
		}
		return nil, err
	}
	m.Body = []byte(body)
	m.Urgent = urgent != 0
	if mentionsJSON != "" && mentionsJSON != "[]" {
		json.Unmarshal([]byte(mentionsJSON), &m.Mentions)
	}
	if t, err := time.Parse(time.RFC3339, createdAt); err == nil {
		m.CreatedAt = t
	}
	if editedAt != "" {
		if t, err := time.Parse(time.RFC3339, editedAt); err == nil {
			m.EditedAt = &t
		}
	}
	if deletedAt != "" {
		if t, err := time.Parse(time.RFC3339, deletedAt); err == nil {
			m.DeletedAt = &t
		}
	}
	return &m, nil
}

func scanMessages(rows *sql.Rows) ([]models.Message, error) {
	var msgs []models.Message
	for rows.Next() {
		var m models.Message
		var createdAt, editedAt, deletedAt string
		var mentionsJSON string
		var urgent int
		var body string
		if err := rows.Scan(
			&m.ID, &m.RoomID, &m.SenderID, &body, &m.FileID,
			&createdAt, &editedAt, &deletedAt,
			&m.ReplyTo, &m.Forwarded, &mentionsJSON, &urgent, &m.PollID,
		); err != nil {
			return nil, err
		}
		m.Body = []byte(body)
		m.Urgent = urgent != 0
		if mentionsJSON != "" && mentionsJSON != "[]" {
			json.Unmarshal([]byte(mentionsJSON), &m.Mentions)
		}
		if t, err := time.Parse(time.RFC3339, createdAt); err == nil {
			m.CreatedAt = t
		}
		if editedAt != "" {
			if t, err := time.Parse(time.RFC3339, editedAt); err == nil {
				m.EditedAt = &t
			}
		}
		if deletedAt != "" {
			if t, err := time.Parse(time.RFC3339, deletedAt); err == nil {
				m.DeletedAt = &t
			}
		}
		msgs = append(msgs, m)
	}
	return msgs, rows.Err()
}
