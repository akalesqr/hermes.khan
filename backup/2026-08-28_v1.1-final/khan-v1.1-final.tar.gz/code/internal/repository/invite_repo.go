package repository

import (
	"time"

	"khan/internal/database"
	"khan/internal/models"
)

// InviteRepo handles private room invitations (دعوت به اتاق خصوصی)
type InviteRepo struct {
	db *database.SQLiteDB
}

func NewInviteRepo(db *database.SQLiteDB) *InviteRepo { return &InviteRepo{db: db} }

// Invite adds a user to a private room
func (r *InviteRepo) Invite(roomID, userID, byUserID int64) error {
	now := time.Now().Format(time.RFC3339)
	_, err := r.db.Exec(
		`INSERT INTO invites (room_id, user_id, by_user_id, created_at) VALUES (?, ?, ?, ?)`,
		roomID, userID, byUserID, now,
	)
	return err
}

// ListForUser returns private room invites for a user
func (r *InviteRepo) ListForUser(userID int64) ([]models.Invite, error) {
	rows, err := r.db.Query(
		`SELECT id, room_id, user_id, by_user_id, created_at FROM invites WHERE user_id = ?`, userID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.Invite
	for rows.Next() {
		var inv models.Invite
		var createdAt string
		if err := rows.Scan(&inv.ID, &inv.RoomID, &inv.UserID, &inv.ByUserID, &createdAt); err != nil {
			return nil, err
		}
		if t, err := time.Parse(time.RFC3339, createdAt); err == nil {
			inv.CreatedAt = t
		}
		out = append(out, inv)
	}
	return out, rows.Err()
}

// Remove deletes an invite
func (r *InviteRepo) Remove(roomID, userID int64) error {
	_, err := r.db.Exec(`DELETE FROM invites WHERE room_id = ? AND user_id = ?`, roomID, userID)
	return err
}
