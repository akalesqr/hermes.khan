package repository

import (
	"database/sql"
	"time"

	"khan/internal/database"
	"khan/internal/models"
)

// ReadRepo handles read receipts (رسید خواندن)
type ReadRepo struct {
	db *database.SQLiteDB
}

func NewReadRepo(db *database.SQLiteDB) *ReadRepo { return &ReadRepo{db: db} }

// SetRead marks a room as read up to messageID for a user
func (r *ReadRepo) SetRead(roomID, userID, messageID int64) error {
	now := time.Now().Format(time.RFC3339)
	_, err := r.db.Exec(
		`INSERT INTO reads (room_id, user_id, last_read, updated_at) VALUES (?, ?, ?, ?)
		 ON CONFLICT(room_id, user_id) DO UPDATE SET last_read = excluded.last_read, updated_at = excluded.updated_at
		 WHERE excluded.last_read > reads.last_read`,
		roomID, userID, messageID, now,
	)
	return err
}

// GetRead returns the last read message id for a user in a room
func (r *ReadRepo) GetRead(roomID, userID int64) (int64, error) {
	var lastRead int64
	err := r.db.QueryRow(
		`SELECT last_read FROM reads WHERE room_id = ? AND user_id = ?`, roomID, userID,
	).Scan(&lastRead)
	if err != nil {
		if err == sql.ErrNoRows {
			return 0, nil
		}
		return 0, err
	}
	return lastRead, nil
}

// ListReadsForRoom returns read positions of all members in a room
func (r *ReadRepo) ListReadsForRoom(roomID int64) ([]models.ReadReceipt, error) {
	rows, err := r.db.Query(
		`SELECT id, room_id, user_id, last_read FROM reads WHERE room_id = ?`, roomID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.ReadReceipt
	for rows.Next() {
		var rr models.ReadReceipt
		if err := rows.Scan(&rr.ID, &rr.RoomID, &rr.UserID, &rr.LastRead); err != nil {
			return nil, err
		}
		out = append(out, rr)
	}
	return out, rows.Err()
}

// UnreadCount returns how many messages a user hasn't read in a room
func (r *ReadRepo) UnreadCount(roomID, userID int64) (int64, error) {
	lastRead, _ := r.GetRead(roomID, userID)
	var count int64
	err := r.db.QueryRow(
		`SELECT COUNT(*) FROM messages WHERE room_id = ? AND id > ? AND deleted_at = ''`,
		roomID, lastRead,
	).Scan(&count)
	return count, err
}
