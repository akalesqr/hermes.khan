package repository

import (
	"database/sql"
	"fmt"
	"strings"
	"time"

	"khan/internal/database"
	"khan/internal/models"
)

// UserRepo handles user persistence on top of SQLiteDB
type UserRepo struct {
	db *database.SQLiteDB
}

func NewUserRepo(db *database.SQLiteDB) *UserRepo { return &UserRepo{db: db} }

// Create inserts a new user
func (r *UserRepo) Create(u *models.User) (int64, error) {
	now := u.CreatedAt.Format(time.RFC3339)
	var lastSeen sql.NullString
	if u.LastSeen != nil {
		lastSeen = sql.NullString{String: u.LastSeen.Format(time.RFC3339), Valid: true}
	}
	res, err := r.db.Exec(
		`INSERT INTO users (username, password_hash, display_name, avatar_path, role, hidden, active, must_change_pwd, created_at, last_seen, status, status_text)
		 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		u.Username, u.PasswordHash, u.DisplayName, u.AvatarPath, u.Role,
		btoi(u.Hidden), btoi(u.Active), btoi(u.MustChangePwd),
		now, nullStr(lastSeen), u.Status, u.StatusText,
	)
	if err != nil {
		return 0, fmt.Errorf("insert user: %w", err)
	}
	return res.LastInsertId()
}

// GetByID finds a user by id
func (r *UserRepo) GetByID(id int64) (*models.User, error) {
	row := r.db.QueryRow(
		`SELECT id, username, password_hash, display_name, avatar_path, role, hidden, active, must_change_pwd, created_at, last_seen, status, status_text
		 FROM users WHERE id = ?`, id,
	)
	return scanUser(row)
}

// GetByUsername finds a user by username (case-insensitive)
func (r *UserRepo) GetByUsername(username string) (*models.User, error) {
	row := r.db.QueryRow(
		`SELECT id, username, password_hash, display_name, avatar_path, role, hidden, active, must_change_pwd, created_at, last_seen, status, status_text
		 FROM users WHERE LOWER(username) = LOWER(?)`, username,
	)
	return scanUser(row)
}

// ListVisible returns all users except hidden super admins
func (r *UserRepo) ListVisible() ([]models.User, error) {
	rows, err := r.db.Query(
		`SELECT id, username, password_hash, display_name, avatar_path, role, hidden, active, must_change_pwd, created_at, last_seen, status, status_text
		 FROM users WHERE hidden = 0 ORDER BY display_name`,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanUsers(rows)
}

// ListAll returns every user (super admin use only)
func (r *UserRepo) ListAll() ([]models.User, error) {
	rows, err := r.db.Query(
		`SELECT id, username, password_hash, display_name, avatar_path, role, hidden, active, must_change_pwd, created_at, last_seen, status, status_text
		 FROM users ORDER BY id`,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanUsers(rows)
}

// CountVisible counts non-hidden users (for license limit)
func (r *UserRepo) CountVisible() (int, error) {
	var n int
	err := r.db.QueryRow(`SELECT COUNT(*) FROM users WHERE hidden = 0`).Scan(&n)
	return n, err
}

// Update updates a user's mutable fields
func (r *UserRepo) Update(u *models.User) error {
	now := u.CreatedAt.Format(time.RFC3339)
	var lastSeen sql.NullString
	if u.LastSeen != nil {
		lastSeen = sql.NullString{String: u.LastSeen.Format(time.RFC3339), Valid: true}
	}
	_, err := r.db.Exec(
		`UPDATE users SET username=?, password_hash=?, display_name=?, avatar_path=?, role=?, hidden=?, active=?, must_change_pwd=?, created_at=?, last_seen=?, status=?, status_text=?
		 WHERE id=?`,
		u.Username, u.PasswordHash, u.DisplayName, u.AvatarPath, u.Role,
		btoi(u.Hidden), btoi(u.Active), btoi(u.MustChangePwd),
		now, nullStr(lastSeen), u.Status, u.StatusText, u.ID,
	)
	return err
}

// UpdatePassword only updates the password hash
func (r *UserRepo) UpdatePassword(id int64, hash string) error {
	_, err := r.db.Exec(
		`UPDATE users SET password_hash = ?, must_change_pwd = 0 WHERE id = ?`, hash, id,
	)
	return err
}

// Delete removes a user entirely (anonymizes messages)
func (r *UserRepo) Delete(id int64) error {
	tx, err := r.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()

	// Anonymize messages
	if _, err := tx.Exec(`UPDATE messages SET sender_id = -1 WHERE sender_id = ?`, id); err != nil {
		return fmt.Errorf("anonymize messages: %w", err)
	}
	// Remove room memberships
	if _, err := tx.Exec(`DELETE FROM room_members WHERE user_id = ?`, id); err != nil {
		return fmt.Errorf("remove room_members: %w", err)
	}
	// Remove sessions
	if _, err := tx.Exec(`DELETE FROM sessions WHERE user_id = ?`, id); err != nil {
		return fmt.Errorf("remove sessions: %w", err)
	}
	// Delete user
	if _, err := tx.Exec(`DELETE FROM users WHERE id = ?`, id); err != nil {
		return fmt.Errorf("delete user: %w", err)
	}

	return tx.Commit()
}

// TouchLastSeen updates the presence timestamp
func (r *UserRepo) TouchLastSeen(id int64) error {
	now := time.Now().Format(time.RFC3339)
	_, err := r.db.Exec(`UPDATE users SET last_seen = ? WHERE id = ?`, now, id)
	return err
}

// SetOnline marks a user online/offline and touches LastSeen
func (r *UserRepo) SetOnline(id int64, online bool) error {
	now := time.Now().Format(time.RFC3339)
	status := "offline"
	if online {
		status = "online"
	}
	_, err := r.db.Exec(`UPDATE users SET status = ?, last_seen = ? WHERE id = ?`, status, now, id)
	return err
}

// SetStatus updates a user's custom status
func (r *UserRepo) SetStatus(id int64, status string) error {
	_, err := r.db.Exec(`UPDATE users SET status = ? WHERE id = ?`, status, id)
	return err
}

// Search finds visible users by username/display name
func (r *UserRepo) Search(q string) ([]models.User, error) {
	pattern := "%" + strings.ToLower(q) + "%"
	rows, err := r.db.Query(
		`SELECT id, username, password_hash, display_name, avatar_path, role, hidden, active, must_change_pwd, created_at, last_seen, status, status_text
		 FROM users WHERE hidden = 0 AND (LOWER(username) LIKE ? OR LOWER(display_name) LIKE ?)
		 LIMIT 50`, pattern, pattern,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanUsers(rows)
}

// --- helpers ---

func scanUser(row *sql.Row) (*models.User, error) {
	var u models.User
	var createdAt, lastSeen string
	var hidden, active, mustChangePwd int
	err := row.Scan(
		&u.ID, &u.Username, &u.PasswordHash, &u.DisplayName, &u.AvatarPath, &u.Role,
		&hidden, &active, &mustChangePwd,
		&createdAt, &lastSeen, &u.Status, &u.StatusText,
	)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, nil
		}
		return nil, err
	}
	u.Hidden = hidden != 0
	u.Active = active != 0
	u.MustChangePwd = mustChangePwd != 0
	if t, err := time.Parse(time.RFC3339, createdAt); err == nil {
		u.CreatedAt = t
	}
	if lastSeen != "" {
		if t, err := time.Parse(time.RFC3339, lastSeen); err == nil {
			u.LastSeen = &t
		}
	}
	return &u, nil
}

func scanUsers(rows *sql.Rows) ([]models.User, error) {
	var users []models.User
	for rows.Next() {
		var u models.User
		var createdAt, lastSeen string
		var hidden, active, mustChangePwd int
		if err := rows.Scan(
			&u.ID, &u.Username, &u.PasswordHash, &u.DisplayName, &u.AvatarPath, &u.Role,
			&hidden, &active, &mustChangePwd,
			&createdAt, &lastSeen, &u.Status, &u.StatusText,
		); err != nil {
			return nil, err
		}
		u.Hidden = hidden != 0
		u.Active = active != 0
		u.MustChangePwd = mustChangePwd != 0
		if t, err := time.Parse(time.RFC3339, createdAt); err == nil {
			u.CreatedAt = t
		}
		if lastSeen != "" {
			if t, err := time.Parse(time.RFC3339, lastSeen); err == nil {
				u.LastSeen = &t
			}
		}
		users = append(users, u)
	}
	return users, rows.Err()
}

func btoi(b bool) int {
	if b {
		return 1
	}
	return 0
}

func nullStr(ns sql.NullString) string {
	if ns.Valid {
		return ns.String
	}
	return ""
}
