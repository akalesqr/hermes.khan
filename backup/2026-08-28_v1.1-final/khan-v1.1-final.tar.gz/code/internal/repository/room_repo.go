package repository

import (
	"database/sql"
	"fmt"
	"sort"
	"time"

	"khan/internal/database"
	"khan/internal/models"
)

// RoomRepo handles room persistence
type RoomRepo struct {
	db *database.SQLiteDB
}

func NewRoomRepo(db *database.SQLiteDB) *RoomRepo { return &RoomRepo{db: db} }

// ListDepartments returns all departments
func (r *RoomRepo) ListDepartments() ([]models.Department, error) {
	rows, err := r.db.Query(`SELECT id, name, created_at FROM departments ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var depts []models.Department
	for rows.Next() {
		var d models.Department
		var createdAt string
		if err := rows.Scan(&d.ID, &d.Name, &createdAt); err != nil {
			return nil, err
		}
		if t, err := time.Parse(time.RFC3339, createdAt); err == nil {
			d.CreatedAt = t
		}
		depts = append(depts, d)
	}
	return depts, rows.Err()
}

// CreateDepartment creates a department
func (r *RoomRepo) CreateDepartment(name string) (*models.Department, error) {
	now := time.Now().Format(time.RFC3339)
	res, err := r.db.Exec(`INSERT INTO departments (name, created_at) VALUES (?, ?)`, name, now)
	if err != nil {
		return nil, fmt.Errorf("insert department: %w", err)
	}
	id, _ := res.LastInsertId()
	return &models.Department{ID: id, Name: name}, nil
}

// DeleteDepartment removes a department
func (r *RoomRepo) DeleteDepartment(id int64) error {
	tx, err := r.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if _, err := tx.Exec(`DELETE FROM departments WHERE id = ?`, id); err != nil {
		return err
	}
	if _, err := tx.Exec(`UPDATE rooms SET department = 0 WHERE department = ?`, id); err != nil {
		return err
	}
	return tx.Commit()
}

// Create inserts a new room and returns its id
func (r *RoomRepo) Create(room *models.Room) (int64, error) {
	now := room.CreatedAt.Format(time.RFC3339)
	res, err := r.db.Exec(
		`INSERT INTO rooms (name, type, creator_id, created_at, department, topic, description, avatar, archived)
		 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		room.Name, room.Type, room.CreatorID, now, room.Department,
		room.Topic, room.Description, room.Avatar, btoi(room.Archived),
	)
	if err != nil {
		return 0, fmt.Errorf("insert room: %w", err)
	}
	return res.LastInsertId()
}

// GetByID finds a room
func (r *RoomRepo) GetByID(id int64) (*models.Room, error) {
	row := r.db.QueryRow(
		`SELECT id, name, type, creator_id, created_at, department, topic, description, avatar, archived
		 FROM rooms WHERE id = ?`, id,
	)
	return scanRoom(row)
}

// ListForUser returns rooms the user belongs to
func (r *RoomRepo) ListForUser(userID int64) ([]models.Room, error) {
	rows, err := r.db.Query(
		`SELECT r.id, r.name, r.type, r.creator_id, r.created_at, r.department, r.topic, r.description, r.avatar, r.archived
		 FROM rooms r
		 INNER JOIN room_members rm ON rm.room_id = r.id
		 WHERE rm.user_id = ?
		 ORDER BY r.id DESC`, userID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanRooms(rows)
}

// ListPublic returns all public rooms
func (r *RoomRepo) ListPublic() ([]models.Room, error) {
	rows, err := r.db.Query(
		`SELECT id, name, type, creator_id, created_at, department, topic, description, avatar, archived
		 FROM rooms WHERE type = 'public'`,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanRooms(rows)
}

// ListPrivateRooms returns private rooms (for admin browsing / invites)
func (r *RoomRepo) ListPrivateRooms(userID int64) ([]models.Room, error) {
	rows, err := r.db.Query(
		`SELECT id, name, type, creator_id, created_at, department, topic, description, avatar, archived
		 FROM rooms WHERE type = 'private'`,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanRooms(rows)
}

// AddMember adds a user to a room
func (r *RoomRepo) AddMember(roomID, userID int64, role string) error {
	now := time.Now().Format(time.RFC3339)
	_, err := r.db.Exec(
		`INSERT OR IGNORE INTO room_members (room_id, user_id, role, joined_at) VALUES (?, ?, ?, ?)`,
		roomID, userID, role, now,
	)
	return err
}

// RemoveMember removes a user from a room
func (r *RoomRepo) RemoveMember(roomID, userID int64) error {
	_, err := r.db.Exec(`DELETE FROM room_members WHERE room_id = ? AND user_id = ?`, roomID, userID)
	return err
}

// IsMember checks membership
func (r *RoomRepo) IsMember(roomID, userID int64) (bool, error) {
	var count int
	err := r.db.QueryRow(
		`SELECT COUNT(*) FROM room_members WHERE room_id = ? AND user_id = ?`, roomID, userID,
	).Scan(&count)
	return count > 0, err
}

// MemberRole returns the member's role in the room
func (r *RoomRepo) MemberRole(roomID, userID int64) (string, error) {
	var role string
	err := r.db.QueryRow(
		`SELECT role FROM room_members WHERE room_id = ? AND user_id = ?`, roomID, userID,
	).Scan(&role)
	if err != nil {
		if err == sql.ErrNoRows {
			return "", nil
		}
		return "", err
	}
	return role, nil
}

// ListMembers returns visible members of a room (hidden excluded)
func (r *RoomRepo) ListMembers(roomID int64) ([]models.User, error) {
	rows, err := r.db.Query(
		`SELECT u.id, u.username, u.password_hash, u.display_name, u.avatar_path, u.role, u.hidden, u.active, u.must_change_pwd, u.created_at, u.last_seen, u.status, u.status_text
		 FROM users u
		 INNER JOIN room_members rm ON rm.user_id = u.id
		 WHERE rm.room_id = ? AND u.hidden = 0
		 ORDER BY u.display_name`, roomID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanUsers(rows)
}

// FindOrCreateDM finds an existing DM between two users or creates one
func (r *RoomRepo) FindOrCreateDM(userA, userB int64) (int64, error) {
	// Try to find existing DM room
	var roomID int64
	err := r.db.QueryRow(
		`SELECT r.id FROM rooms r
		 INNER JOIN room_members rm1 ON rm1.room_id = r.id AND rm1.user_id = ?
		 INNER JOIN room_members rm2 ON rm2.room_id = r.id AND rm2.user_id = ?
		 WHERE r.type = 'dm'
		 LIMIT 1`, userA, userB,
	).Scan(&roomID)
	if err == nil {
		return roomID, nil
	}
	if err != sql.ErrNoRows {
		return 0, err
	}

	// Create new DM room
	tx, err := r.db.Begin()
	if err != nil {
		return 0, err
	}
	defer tx.Rollback()

	now := time.Now().Format(time.RFC3339)
	res, err := tx.Exec(
		`INSERT INTO rooms (name, type, creator_id, created_at) VALUES (?, 'dm', ?, ?)`,
		"", userA, now,
	)
	if err != nil {
		return 0, err
	}
	newRoomID, _ := res.LastInsertId()

	for _, uid := range []int64{userA, userB} {
		if _, err := tx.Exec(
			`INSERT INTO room_members (room_id, user_id, role, joined_at) VALUES (?, ?, 'member', ?)`,
			newRoomID, uid, now,
		); err != nil {
			return 0, err
		}
	}

	if err := tx.Commit(); err != nil {
		return 0, err
	}
	return newRoomID, nil
}

// UpdateRoom updates room name
func (r *RoomRepo) UpdateRoom(room *models.Room) error {
	_, err := r.db.Exec(`UPDATE rooms SET name = ? WHERE id = ?`, room.Name, room.ID)
	return err
}

// DeleteRoom removes a room and its members/messages
func (r *RoomRepo) DeleteRoom(roomID int64) error {
	tx, err := r.db.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if _, err := tx.Exec(`DELETE FROM messages WHERE room_id = ?`, roomID); err != nil {
		return err
	}
	if _, err := tx.Exec(`DELETE FROM room_members WHERE room_id = ?`, roomID); err != nil {
		return err
	}
	if _, err := tx.Exec(`DELETE FROM rooms WHERE id = ?`, roomID); err != nil {
		return err
	}
	return tx.Commit()
}

// --- helpers ---

func scanRoom(row *sql.Row) (*models.Room, error) {
	var room models.Room
	var createdAt string
	var archived int
	err := row.Scan(
		&room.ID, &room.Name, &room.Type, &room.CreatorID,
		&createdAt, &room.Department, &room.Topic, &room.Description, &room.Avatar,
		&archived,
	)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, nil
		}
		return nil, err
	}
	room.Archived = archived != 0
	if t, err := time.Parse(time.RFC3339, createdAt); err == nil {
		room.CreatedAt = t
	}
	return &room, nil
}

func scanRooms(rows *sql.Rows) ([]models.Room, error) {
	var rooms []models.Room
	for rows.Next() {
		var room models.Room
		var createdAt string
		var archived int
		if err := rows.Scan(
			&room.ID, &room.Name, &room.Type, &room.CreatorID,
			&createdAt, &room.Department, &room.Topic, &room.Description, &room.Avatar,
			&archived,
		); err != nil {
			return nil, err
		}
		room.Archived = archived != 0
		if t, err := time.Parse(time.RFC3339, createdAt); err == nil {
			room.CreatedAt = t
		}
		rooms = append(rooms, room)
	}
	// Sort by ID descending (newest first), consistent with old behavior
	sort.Slice(rooms, func(i, j int) bool { return rooms[i].ID > rooms[j].ID })
	return rooms, rows.Err()
}
