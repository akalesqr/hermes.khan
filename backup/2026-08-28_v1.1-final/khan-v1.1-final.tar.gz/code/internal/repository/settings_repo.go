package repository

import (
	"database/sql"
	"fmt"

	"khan/internal/database"
)

// SettingsRepo provides key-value settings storage
type SettingsRepo struct {
	db *database.SQLiteDB
}

func NewSettingsRepo(db *database.SQLiteDB) *SettingsRepo {
	return &SettingsRepo{db: db}
}

// Get returns the value for a key, or empty string if not found
func (r *SettingsRepo) Get(key string) (string, error) {
	var val string
	err := r.db.QueryRow("SELECT value FROM settings WHERE key = ?", key).Scan(&val)
	if err != nil {
		if err == sql.ErrNoRows {
			return "", nil // not found = empty
		}
		return "", fmt.Errorf("settings get %s: %w", key, err)
	}
	return val, nil
}

// Set upserts a key-value pair
func (r *SettingsRepo) Set(key, value string) error {
	_, err := r.db.Exec("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", key, value)
	if err != nil {
		return fmt.Errorf("settings set %s: %w", key, err)
	}
	return nil
}

// GetAll returns all settings as a map
func (r *SettingsRepo) GetAll() (map[string]string, error) {
	rows, err := r.db.Query("SELECT key, value FROM settings")
	if err != nil {
		return nil, fmt.Errorf("settings list: %w", err)
	}
	defer rows.Close()

	result := make(map[string]string)
	for rows.Next() {
		var k, v string
		if err := rows.Scan(&k, &v); err != nil {
			return nil, fmt.Errorf("settings scan: %w", err)
		}
		result[k] = v
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("settings rows: %w", err)
	}
	return result, nil
}
