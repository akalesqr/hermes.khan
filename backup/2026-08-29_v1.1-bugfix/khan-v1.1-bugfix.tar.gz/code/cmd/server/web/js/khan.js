/* ============================================================
   خان — Application logic (Vue 3, connected to Go backend)
   Real API integration for all features
   ============================================================ */

const I18N = {
  fa: {
    tagline: 'فضای امن گفتگوی تیم شما',
    toggleTheme: 'تغییر حالت روشن/تیره',
    firstRun: 'اولین راه‌اندازی سیستم',
    companyName: 'نام شرکت', companyNamePh: 'مثلاً شرکت آریانا',
    adminUsername: 'نام کاربری ادمین', usernamePh: 'نام کاربری',
    displayName: 'نام نمایشی', displayNamePh: 'نام و نام خانوادگی',
    password: 'رمز عبور', username: 'نام کاربری',
    createWorkspace: 'ایجاد فضای کاری', login: 'ورود',
    firstTimeQ: 'اولین بار است از خان استفاده می‌کنید؟', setupLink: 'راه‌اندازی سیستم',
    haveAccountQ: 'قبلاً حساب ساخته‌اید؟', backToLogin: 'بازگشت به ورود',
    freeUpTo: 'رایگان برای شرکت‌های زیر ۲۰ نفر',
    searchChats: 'جستجوی گفتگوها…',
    tabChats: 'چت‌ها', tabRooms: 'اتاق‌ها', tabSearch: 'جستجو', tabUsers: 'کاربران',
    noChats: 'گفتگویی یافت نشد', noDept: 'بدون دپارتمان',
    newRoom: 'اتاق جدید', globalSearchPh: 'جستجو در همه پیام‌ها…',
    noResults: 'نتیجه‌ای یافت نشد', typeToSearch: 'برای جستجو تایپ کنید',
    online: 'آنلاین', offline: 'آفلاین',
    adminPanel: 'پنل مدیریت', logout: 'خروج',
    welcomeTitle: 'به خان خوش آمدید', welcomeSub: 'از لیست کنار، یک گفتگو را باز کنید',
    openSidebar: 'نمایش گفتگوها',
    pinnedMsgs: 'پیام پین‌شده', urgentBanner: 'این گفتگو حاوی یک پیام فوری است',
    isTyping: 'در حال تایپ است', edited: '(ویرایش‌شده)',
    replyingTo: 'در پاسخ به', dropFiles: 'فایل را اینجا رها کنید',
    typeMessage: 'پیامی بنویسید…', members: 'اعضا', addMember: 'افزودن عضو…',
    roomName: 'نام اتاق', roomNamePh: 'مثلاً تیم فروش', roomType: 'نوع اتاق',
    department: 'دپارتمان', cancel: 'انصراف', create: 'ایجاد',
    newUser: 'کاربر جدید', role: 'نقش', newDept: 'دپارتمان جدید', deptName: 'نام دپارتمان',
    newPoll: 'نظرسنجی جدید', question: 'سوال', questionPh: 'سوال نظرسنجی را بنویسید',
    option: 'گزینه', addOption: 'افزودن گزینه', publish: 'انتشار',
    forwardMsg: 'فوروارد پیام', reply: 'پاسخ', forward: 'فوروارد', pin: 'پین کردن',
    unpin: 'برداشتن پین', markUrgent: 'علامت‌گذاری فوری', edit: 'ویرایش', delete: 'حذف',
    atUsers: 'کاربران', atLicense: 'لایسنس', atNetwork: 'شبکه', atBackup: 'بکاپ',
    atLogs: 'لاگ‌ها', atDepts: 'دپارتمان‌ها', usersOf: 'کاربر فعال',
    colName: 'نام', colRole: 'نقش', colStatus: 'وضعیت', active: 'فعال', inactive: 'غیرفعال',
    exportExcel: 'خروجی اکسل', exported: 'فایل اکسل آماده دانلود شد',
    licenseDesc: 'وضعیت و مدیریت لایسنس نرم‌افزار', activeUsers: 'کاربران فعال',
    licenseStatus: 'وضعیت لایسنس', licenseActive: 'فعال', expiresOn: 'تاریخ انقضا',
    uploadKey: 'آپلود فایل لایسنس', uploadKeySub: 'فایل .key رمزنگاری‌شده',
    chooseFile: 'انتخاب فایل', keyUploaded: 'فایل لایسنس با موفقیت اعمال شد',
    networkDesc: 'تنظیمات سرور و هویت سازمانی', serverAddr: 'آدرس سرور', port: 'پورت',
    version: 'نسخه نرم‌افزار', companyLogo: 'لوگوی شرکت', orgColor: 'رنگ سازمانی',
    upload: 'آپلود', saveChanges: 'ذخیره تغییرات', saved: 'تغییرات ذخیره شد',
    backupDesc: 'پشتیبان‌گیری و بازیابی اطلاعات', backupNow: 'بکاپ فوری',
    downloaded: 'دانلود آغاز شد', restored: 'بازیابی با موفقیت انجام شد',
    logsDesc: 'رویدادهای اخیر سرور', refresh: 'بروزرسانی', logsRefreshed: 'لاگ‌ها بروزرسانی شد',
    deptsDesc: 'مدیریت دپارتمان‌های سازمان', rooms: 'اتاق',
    roleAdmin: 'ادمین', roleManager: 'مدیر', roleSupervisor: 'سوپروایزر', roleUser: 'کاربر عادی', roleSuperAdmin: 'مدیر اصلی',
  },
  en: {
    tagline: "Your team's secure conversation space",
    toggleTheme: 'Toggle light/dark',
    firstRun: 'First-time system setup',
    companyName: 'Company name', companyNamePh: 'e.g. Ariana Co.',
    adminUsername: 'Admin username', usernamePh: 'Username',
    displayName: 'Display name', displayNamePh: 'Full name',
    password: 'Password', username: 'Username',
    createWorkspace: 'Create workspace', login: 'Sign in',
    firstTimeQ: 'First time using Khan?', setupLink: 'Set up system',
    haveAccountQ: 'Already have an account?', backToLogin: 'Back to sign in',
    freeUpTo: 'Free for companies under 20 people',
    searchChats: 'Search chats…',
    tabChats: 'Chats', tabRooms: 'Rooms', tabSearch: 'Search', tabUsers: 'Users',
    noChats: 'No chats found', noDept: 'No department',
    newRoom: 'New room', globalSearchPh: 'Search all messages…',
    noResults: 'No results found', typeToSearch: 'Type to search',
    online: 'Online', offline: 'Offline',
    adminPanel: 'Admin panel', logout: 'Log out',
    welcomeTitle: 'Welcome to Khan', welcomeSub: 'Open a conversation from the list',
    openSidebar: 'Show conversations',
    pinnedMsgs: 'pinned message', urgentBanner: 'This conversation has an urgent message',
    isTyping: 'is typing', edited: '(edited)',
    replyingTo: 'Replying to', dropFiles: 'Drop file here',
    typeMessage: 'Type a message…', members: 'Members', addMember: 'Add member…',
    roomName: 'Room name', roomNamePh: 'e.g. Sales team', roomType: 'Room type',
    department: 'Department', cancel: 'Cancel', create: 'Create',
    newUser: 'New user', role: 'Role', newDept: 'New department', deptName: 'Department name',
    newPoll: 'New poll', question: 'Question', questionPh: 'Write the poll question',
    option: 'Option', addOption: 'Add option', publish: 'Publish',
    forwardMsg: 'Forward message', reply: 'Reply', forward: 'Forward', pin: 'Pin',
    unpin: 'Unpin', markUrgent: 'Mark urgent', edit: 'Edit', delete: 'Delete',
    atUsers: 'Users', atLicense: 'License', atNetwork: 'Network', atBackup: 'Backup',
    atLogs: 'Logs', atDepts: 'Departments', usersOf: 'active users',
    colName: 'Name', colRole: 'Role', colStatus: 'Status', active: 'Active', inactive: 'Inactive',
    exportExcel: 'Export Excel', exported: 'Excel file ready for download',
    licenseDesc: 'Software license status and management', activeUsers: 'Active users',
    licenseStatus: 'License status', licenseActive: 'Active', expiresOn: 'Expires on',
    uploadKey: 'Upload license file', uploadKeySub: 'Encrypted .key file',
    chooseFile: 'Choose file', keyUploaded: 'License file applied successfully',
    networkDesc: 'Server settings and organization identity', serverAddr: 'Server address', port: 'Port',
    version: 'Software version', companyLogo: 'Company logo', orgColor: 'Organization color',
    upload: 'Upload', saveChanges: 'Save changes', saved: 'Changes saved',
    backupDesc: 'Backup and restore data', backupNow: 'Backup now',
    downloaded: 'Download started', restored: 'Restored successfully',
    logsDesc: 'Recent server events', refresh: 'Refresh', logsRefreshed: 'Logs refreshed',
    deptsDesc: 'Manage organization departments', rooms: 'rooms',
    roleAdmin: 'Admin', roleManager: 'Manager', roleSupervisor: 'Supervisor', roleUser: 'User', roleSuperAdmin: 'Super Admin',
  }
};

const THEME_COLORS = [
  { id: 'khan',     swatch: '#e8a33d', label: { fa: 'خان (طلایی)', en: 'Khan (gold)' } },
  { id: 'sapphire', swatch: '#3b82f6', label: { fa: 'یاقوت‌کبود (آبی)', en: 'Sapphire' } },
  { id: 'spring',   swatch: '#10b981', label: { fa: 'بهار (سبز)', en: 'Spring' } },
  { id: 'night',    swatch: '#8b5cf6', label: { fa: 'شب (بنفش)', en: 'Night' } },
  { id: 'sunset',   swatch: '#f97316', label: { fa: 'غروب (نارنجی)', en: 'Sunset' } },
  { id: 'frost',    swatch: '#64748b', label: { fa: 'یخبندان (خاکستری)', en: 'Frost' } },
];

function uid(prefix) { return prefix + '_' + Math.random().toString(36).slice(2, 9); }
function faTime(h, m) { return String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0'); }
function jTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  return faTime(d.getHours(), d.getMinutes());
}
function faDate(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleDateString('fa-IR', { day: 'numeric', month: 'long' });
}

const { createApp } = Vue;

createApp({
  template: document.getElementById('app-template').innerHTML,

  data() {
    return {
      locale: 'fa',
      themeMode: 'dark',
      themeColor: 'khan',
      themeColors: THEME_COLORS,

      screen: 'login',
      needsSetup: false,
      loginForm: { username: '', password: '' },
      setupForm: { company: '', username: '', displayName: '', password: '' },

      isMobile: window.innerWidth < 768,
      sidebarOpen: window.innerWidth >= 768,
      infoPanelOpen: false,
      sidebarTab: 'chats',
      chatSearch: '',
      globalSearch: '',
      chatHeaderSearchOpen: false,
      collapsedDepts: {},

      token: null,
      currentUser: null,
      users: [],
      rooms: [],
      departments: [],
      messagesByRoom: {},
      activeRoomId: null,
      unreadMap: {},

      composerText: '',
      replyingTo: null,
      dragOver: false,

      showCreateRoom: false, showCreateUser: false, showCreateDept: false, showPoll: false, showForward: false,
      newRoom: { name: '', type: 'group', department: '' },
      newUser: { username: '', displayName: '', password: '', role: 'user' },
      newDeptName: '',
      poll: { question: '', options: ['', ''] },
      forwardMsg: null,
      memberToAdd: '',

      adminOpen: false, adminTab: 'users', adminNavOpen: false,
      company: { name: '', serverAddr: '', port: '', version: '1.1.0', userLimit: 20 },
      backups: [],
      serverLogs: [],

      ctxMenu: { show: false, x: 0, y: 0, msg: null },
      toastMsg: '',
      roomTypes: ['group', 'public', 'private', 'channel'],
      _wsReconnectTimer: null,
    };
  },

  computed: {
    dir() { return this.locale === 'fa' ? 'rtl' : 'ltr'; },
    theme() { return this.themeColor + '-' + this.themeMode; },
    activeRoom() { return this.rooms.find(r => r.id === this.activeRoomId) || null; },

    groupedChats() {
      const q = this.chatSearch.trim();
      const list = this.rooms.filter(r => !q || r.name.includes(q));
      const withDept = {};
      list.forEach(r => {
        const key = r.department || (this.locale === 'fa' ? 'مکالمات مستقیم' : 'Direct messages');
        (withDept[key] = withDept[key] || []).push(r);
      });
      return Object.keys(withDept).map(dept => ({ dept, rooms: withDept[dept] }));
    },

    messageGroups() {
      if (!this.activeRoom) return [];
      const msgs = this.messagesByRoom[this.activeRoom.id] || [];
      const groups = [];
      let lastDate = null, lastSender = null;
      msgs.forEach((m, i) => {
        if (m.date !== lastDate) { groups.push({ date: m.date, msgs: [] }); lastDate = m.date; lastSender = null; }
        m.showAvatar = m.senderName !== lastSender;
        m.showName = m.senderName !== lastSender;
        lastSender = m.senderName;
        groups[groups.length - 1].msgs.push(m);
      });
      return groups;
    },

    searchResults() {
      const q = this.globalSearch.trim();
      if (!q) return [];
      const out = [];
      Object.keys(this.messagesByRoom).forEach(rid => {
        if (Array.isArray(this.messagesByRoom[rid])) {
          this.messagesByRoom[rid].forEach(m => { if (m.text && m.text.includes(q)) out.push({ ...m, roomId: rid }); });
        }
      });
      return out;
    },
  },

  watch: {
    dir(v) { document.documentElement.setAttribute('dir', v); document.documentElement.setAttribute('lang', this.locale); },
    theme(v) { document.documentElement.setAttribute('data-theme', v); },
    themeMode(v) { document.documentElement.setAttribute('data-theme', this.themeColor + '-' + v); },
    themeColor(v) { document.documentElement.setAttribute('data-theme', v + '-' + this.themeMode); },
  },

  methods: {
    t(key) { return (I18N[this.locale] && I18N[this.locale][key]) || key; },
    initials(name) {
      if (!name) return '';
      const parts = name.trim().split(' ').filter(Boolean);
      return parts.slice(0, 2).map(w => w[0]).join('');
    },
    avatarStyle(color) { return color ? { background: `linear-gradient(145deg, ${color}, ${color}cc)` } : {}; },
    roleLabel(role) {
      if (!role) return '';
      const map = {
        'adm': 'roleAdmin', 'admin': 'roleAdmin',
        'sadm': 'roleSuperAdmin', 'superadmin': 'roleSuperAdmin',
        'sup': 'roleSupervisor', 'supervisor': 'roleSupervisor',
        'user': 'roleUser',
        'mgr': 'roleManager', 'manager': 'roleManager',
      };
      const key = map[role] || ('role' + role.charAt(0).toUpperCase() + role.slice(1));
      return this.t(key);
    },
    roomTypeLabel(ty) {
      const map = { fa: { group: 'گروه', public: 'عمومی', private: 'خصوصی', channel: 'کانال', dm: 'گفتگوی خصوصی' },
                    en: { group: 'Group', public: 'Public', private: 'Private', channel: 'Channel', dm: 'Direct message' } };
      return (map[this.locale] && map[this.locale][ty]) || ty;
    },
    roomName(id) { const r = this.rooms.find(r => r.id === id); return r ? r.name : ''; },
    roomOnlineCount(room) { return this.roomMembers(room).filter(u => u.online).length; },
    roomMembers(room) { return (room.members || []).map(id => this.users.find(u => u.id === id)).filter(Boolean); },
    nonMembers(room) { return this.users.filter(u => !(room.members || []).includes(u.id)); },
    pinnedCount(room) { return (room.pinned || []).length; },

    toggleMode() { this.themeMode = this.themeMode === 'dark' ? 'light' : 'dark'; },
    toggleDeptCollapse(dept) { this.collapsedDepts[dept] = !this.collapsedDepts[dept]; },

    toast(msg) { this.toastMsg = msg; clearTimeout(this._toastTimer); this._toastTimer = setTimeout(() => this.toastMsg = '', 2600); },

    // ============ BUG FIX: autoGrow for textarea ============
    autoGrow(e) {
      const el = e.target || e;
      el.style.height = 'auto';
      el.style.height = el.scrollHeight + 'px';
    },

    // ============ BUG FIX: openAdmin method ============
    openAdmin() {
      this.adminOpen = true;
      this.adminTab = 'users';
      this.adminNavOpen = false;
    },

    // ============ AUTH & SETUP ============
    async doLogin() {
      try {
        const res = await this.api('/api/auth/login', { method: 'POST', body: this.loginForm });
        if (res.token) {
          this.token = res.token;
          this.currentUser = res.user;
          localStorage.setItem('khan_token', this.token);
          this.screen = 'app';
          await this.loadAll();
        }
      } catch (e) { this.toast(e.message || this.t('login')); }
    },

    // BUG FIX #2: doSetup uses setupForm for login, not empty loginForm
    async doSetup() {
      try {
        await this.api('/api/setup', {
          method: 'POST',
          body: { admin_username: this.setupForm.username, admin_password: this.setupForm.password, company_name: this.setupForm.company }
        });
        this.needsSetup = false;
        // Fill loginForm from setupForm so doLogin works
        this.loginForm.username = this.setupForm.username;
        this.loginForm.password = this.setupForm.password;
        await this.doLogin();
      } catch (e) { this.toast(e.message || this.t('createWorkspace')); }
    },

    async loadSession() {
      const saved = localStorage.getItem('khan_token');
      if (!saved) return;
      this.token = saved;
      try {
        const user = await this.api('/api/auth/me');
        this.currentUser = user;
        this.screen = 'app';
        await this.loadAll();
      } catch (e) {
        localStorage.removeItem('khan_token');
        this.token = null;
        this.screen = 'login';
      }
    },

    logout() {
      this.api('/api/auth/logout', { method: 'POST' }).catch(() => {});
      localStorage.removeItem('khan_token');
      this.token = null;
      this.currentUser = null;
      this.rooms = [];
      this.messagesByRoom = {};
      this.activeRoomId = null;
      if (this.ws) { try { this.ws.close(); } catch {} this.ws = null; }
      clearTimeout(this._wsReconnectTimer);
      this.screen = 'login';
    },

    // ============ API HELPER ============
    async api(path, opts = {}) {
      const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
      if (this.token) headers['Authorization'] = 'Bearer ' + this.token;
      const body = opts.body ? JSON.stringify(opts.body) : undefined;
      const res = await fetch(path, { ...opts, headers, body, credentials: 'same-origin' });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'خطای سرور');
      return data;
    },

    // ============ DATA LOADING ============
    async loadAll() {
      try {
        const [users, rooms] = await Promise.all([
          this.api('/api/users'),
          this.api('/api/rooms')
        ]);
        this.users = Array.isArray(users) ? users : [];
        this.rooms = Array.isArray(rooms) ? rooms : [];
        this.unreadMap = JSON.parse(localStorage.getItem('khan_readmap') || '{}');
        // Load messages for all rooms in background
        this.rooms.forEach(r => this.loadMessages(r.id).catch(() => {}));
        this.loadRoomsDiscovery();
        this.loadDepartments();
        this.loadPinned();
        // Auto-open first room
        if (!this.activeRoomId && this.rooms.length) {
          this.openRoom(this.rooms[0].id);
        }
        // Load company name
        const company = await this.api('/api/settings/company');
        this.company.name = company.company_name || '';
        // Connect WebSocket (only if not already connected)
        if (!this.ws || this.ws.readyState === WebSocket.CLOSED) {
          this.connectWS();
        }
      } catch (e) { console.error('loadAll error:', e); }
    },

    async loadRoomsDiscovery() {
      try {
        const pub = await this.api('/api/rooms/public').catch(() => []);
        const existing = new Set(this.rooms.map(r => r.id));
        (Array.isArray(pub) ? pub : []).forEach(r => {
          if (!existing.has(r.id)) { this.rooms.push(r); existing.add(r.id); }
        });
      } catch (e) { console.error('loadRoomsDiscovery:', e); }
    },

    async loadDepartments() {
      try {
        const depts = await this.api('/api/departments');
        this.departments = Array.isArray(depts) ? depts : [];
      } catch (e) { console.error('loadDepartments:', e); }
    },

    async loadMessages(roomId) {
      try {
        const msgs = await this.api('/api/messages/' + roomId);
        this.messagesByRoom[roomId] = Array.isArray(msgs) ? msgs.map(m => ({
          ...m,
          time: jTime(m.created_at),
          date: faDate(m.created_at),
          reactions: (m.reactions || []).map(r => ({ emoji: r.emoji, count: r.count, byMe: r.by_me })),
          mine: m.sender_id === this.currentUser?.id,
        })) : [];
      } catch (e) { console.error('loadMessages:', e); }
    },

    async loadMembers(roomId) {
      try {
        const members = await this.api('/api/rooms/' + roomId + '/members');
        const room = this.rooms.find(r => r.id === roomId);
        if (room) room.members = Array.isArray(members) ? members.map(m => m.id) : [];
      } catch (e) { console.error('loadMembers:', e); }
    },

    async loadPinned() {
      try {
        if (!this.activeRoom) return;
        const pins = await this.api('/api/messages/' + this.activeRoom.id + '/pins');
        this.activeRoom.pinned = Array.isArray(pins) ? pins : [];
      } catch (e) { console.error('loadPinned:', e); }
    },

    // ============ ROOMS ============
    openRoom(id) {
      this.activeRoomId = id;
      const r = this.rooms.find(r => r.id === id);
      if (r) { r.unread = 0; this.unreadMap[id] = 0; localStorage.setItem('khan_readmap', JSON.stringify(this.unreadMap)); }
      if (this.isMobile) this.sidebarOpen = false;
      this.infoPanelOpen = false;
      this.loadMessages(id);
      this.loadMembers(id);
      this.loadPinned();
      this.$nextTick(() => this.scrollToBottom());
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ type: 'mark_read', room_id: id, last_id: (this.messagesByRoom[id] || []).slice(-1)[0]?.id || 0 }));
      }
    },

    openDM(user) {
      let room = this.rooms.find(r => r.type === 'dm' && r.dm_with === user.id);
      if (!room) {
        room = { id: uid('room'), name: user.name, type: 'dm', dm_with: user.id, color: user.color,
          department: null, members: [this.currentUser.id, user.id], online: user.online,
          last_msg: '', last_time: '', unread: 0, pinned: [] };
        this.rooms.unshift(room);
        this.messagesByRoom[room.id] = [];
      }
      this.sidebarTab = 'chats';
      this.openRoom(room.id);
    },

    async createRoom() {
      const name = (this.newRoom.name || '').trim();
      if (name.length < 2) { this.toast(this.locale === 'fa' ? 'نام اتاق حداقل ۲ کاراکتر' : 'Room name must be at least 2 characters'); return; }
      try {
        const body = { name, type: this.newRoom.type, department: this.newRoom.department ? parseInt(this.newRoom.department) : 0 };
        const room = await this.api('/api/rooms', { method: 'POST', body });
        this.rooms.unshift(room);
        this.messagesByRoom[room.id] = [];
        this.showCreateRoom = false;
        this.newRoom = { name: '', type: 'group', department: '' };
        this.sidebarTab = 'chats';
        this.openRoom(room.id);
      } catch (e) { this.toast(e.message); }
    },

    // BUG FIX #3 & #4: joinRoom uses room.id (not object), no duplicate loadAll
    async joinRoom(room) {
      if (!room || !room.id) return;
      try {
        await this.api('/api/rooms/' + room.id + '/join', { method: 'POST' });
        // Reload only the joined room + members instead of full loadAll
        await this.loadMessages(room.id);
        await this.loadMembers(room.id);
        this.openRoom(room.id);
      } catch (e) { this.toast(e.message); }
    },

    // ============ MESSAGES ============
    // BUG FIX #12: sendMessage captures roomId before async
    async sendMessage() {
      const text = (this.composerText || '').trim();
      if (!text || !this.activeRoom) return;
      // BUG FIX: text length limit
      const sendText = text.length > 2000 ? text.slice(0, 2000) : text;
      const roomId = this.activeRoom.id;
      const replyTo = this.replyingTo ? this.replyingTo.id : null;
      this.composerText = '';
      this.replyingTo = null;
      try {
        const msg = await this.api('/api/messages/' + roomId, {
          method: 'POST',
          body: { text: sendText, reply_to: replyTo }
        });
        this.messagesByRoom[roomId] = this.messagesByRoom[roomId] || [];
        this.messagesByRoom[roomId].push({
          ...msg,
          time: jTime(msg.created_at),
          date: faDate(msg.created_at),
          mine: true,
          reactions: [],
        });
        const room = this.rooms.find(r => r.id === roomId);
        if (room) { room.last_msg = sendText; room.last_time = jTime(msg.created_at); }
        // Only scroll if still on same room
        if (this.activeRoomId === roomId) {
          this.$nextTick(() => { this.scrollToBottom(); this.$refs.composerInput && (this.$refs.composerInput.style.height = 'auto'); });
        }
      } catch (e) { this.toast(e.message); this.composerText = sendText; }
    },

    scrollToBottom() { const el = this.$refs.msgList; if (el) el.scrollTop = el.scrollHeight; },
    mockAttach() { this.toast(this.locale === 'fa' ? 'انتخاب فایل (نیاز به پیاده‌سازی)' : 'File picker (TODO)'); },
    onDrop() { this.dragOver = false; this.toast(this.locale === 'fa' ? 'بارگذاری فایل (نیاز به پیاده‌سازی)' : 'File upload (TODO)'); },

    startReply(m) { this.replyingTo = m; this.$refs.composerInput && this.$refs.composerInput.focus(); },
    startEdit(m) { m.editing = true; m.editDraft = m.text; },
    // BUG FIX: saveEdit trims whitespace
    async saveEdit(m) {
      const text = (m.editDraft || '').trim();
      if (!text) return;
      try {
        await this.api('/api/messages/' + m.id + '/edit', { method: 'POST', body: { text } });
        m.text = text;
        m.editing = false;
        m.edited = true;
      } catch (e) { this.toast(e.message); }
    },
    // BUG FIX #1: deleteMessage safe indexOf
    async deleteMessage(m) {
      try {
        await this.api('/api/messages/' + m.id, { method: 'DELETE' });
        const arr = this.messagesByRoom[this.activeRoomId];
        if (Array.isArray(arr)) {
          const i = arr.indexOf(m);
          if (i > -1) arr.splice(i, 1);
        }
      } catch (e) { this.toast(e.message); }
    },

    quickReact(m, emoji) { this.toggleReaction(m, emoji); },
    async toggleReaction(m, emoji) {
      if (!m || !emoji) return;
      const existing = (m.reactions || []).find(r => r.emoji === emoji);
      if (existing) {
        if (existing.byMe) {
          m.reactions = m.reactions.filter(r => r !== existing);
          try { await this.api('/api/messages/' + m.id + '/reactions', { method: 'DELETE', body: { emoji } }); } catch {}
        } else {
          existing.count++; existing.byMe = true;
          try { await this.api('/api/messages/' + m.id + '/reactions', { method: 'POST', body: { emoji } }); } catch {}
        }
      } else {
        m.reactions = m.reactions || [];
        m.reactions.push({ emoji, count: 1, byMe: true });
        try { await this.api('/api/messages/' + m.id + '/reactions', { method: 'POST', body: { emoji } }); } catch {}
      }
    },

    async togglePin(m) {
      if (!m || !this.activeRoom) return;
      const room = this.activeRoom; room.pinned = room.pinned || [];
      const idx = room.pinned.findIndex(p => p.id === m.id);
      const pinning = idx === -1;
      if (!pinning) { room.pinned.splice(idx, 1); } else { room.pinned.push({ id: m.id, senderName: m.senderName, text: m.text }); }
      try {
        await this.api('/api/messages/' + m.id + (pinning ? '/pin' : '/unpin'), { method: 'POST' });
        m.pinned = pinning;
      } catch (e) {
        // Revert on error
        if (pinning) { room.pinned.pop(); } else { room.pinned.push({ id: m.id, senderName: m.senderName, text: m.text }); }
      }
    },

    markUrgent() {
      if (!this.activeRoom) return;
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ type: 'mark_urgent', room_id: this.activeRoom.id }));
      }
      this.toast(this.locale === 'fa' ? 'پیام به عنوان فوری علامت‌گذاری شد' : 'Marked as urgent');
    },

    openContextMenu(e, m) { e.preventDefault(); this.ctxMenu = { show: true, x: e.clientX, y: e.clientY, msg: m }; },
    async forwardTo(room) {
      if (!this.forwardMsg || !room) return;
      try {
        await this.api('/api/messages/' + this.forwardMsg.id + '/forward', { method: 'POST', body: { room_id: room.id } });
        this.showForward = false; this.forwardMsg = null;
        this.toast(this.locale === 'fa' ? 'پیام فوروارد شد' : 'Message forwarded');
      } catch (e) { this.toast(e.message); }
    },

    // ============ MEMBERS ============
    async addMember(room) {
      if (!room || !this.memberToAdd) return;
      try {
        await this.api('/api/rooms/' + room.id + '/members', { method: 'POST', body: { user_id: this.memberToAdd } });
        room.members = room.members || []; room.members.push(this.memberToAdd);
        this.memberToAdd = '';
        this.toast(this.locale === 'fa' ? 'عضو اضافه شد' : 'Member added');
      } catch (e) { this.toast(e.message); }
    },
    async removeMember(room, u) {
      if (!room || !u) return;
      try {
        await this.api('/api/rooms/' + room.id + '/members/' + u.id, { method: 'DELETE' });
        room.members = (room.members || []).filter(id => id !== u.id);
        this.toast(this.locale === 'fa' ? 'عضو حذف شد' : 'Member removed');
      } catch (e) { this.toast(e.message); }
    },

    // ============ ADMIN ============
    async createUser() {
      const username = (this.newUser.username || '').trim();
      const displayName = (this.newUser.displayName || '').trim();
      const password = (this.newUser.password || '').trim();
      if (username.length < 2) { this.toast(this.locale === 'fa' ? 'نام کاربری حداقل ۲ کاراکتر' : 'Username must be at least 2 characters'); return; }
      if (password.length < 6) { this.toast(this.locale === 'fa' ? 'رمز عبور حداقل ۶ کاراکتر' : 'Password must be at least 6 characters'); return; }
      try {
        await this.api('/api/users', { method: 'POST', body: { username, displayName, password, role: this.newUser.role } });
        this.showCreateUser = false;
        this.newUser = { username: '', displayName: '', password: '', role: 'user' };
        this.toast(this.locale === 'fa' ? 'کاربر ایجاد شد' : 'User created');
        this.loadUsers();
      } catch (e) { this.toast(e.message); }
    },
    // BUG FIX #8: resetPassword calls API
    async resetPassword(u) {
      if (!u) return;
      try {
        const res = await this.api('/api/users/' + u.id + '/reset-password', { method: 'POST' });
        this.toast((this.locale === 'fa' ? 'رمز عبور ریست شد: ' : 'Password reset: ') + (res.new_password || ''));
      } catch (e) { this.toast(e.message); }
    },
    async deleteUser(u) {
      if (!u) return;
      try {
        await this.api('/api/users/' + u.id, { method: 'DELETE' });
        this.users = this.users.filter(x => x.id !== u.id);
        this.toast(this.locale === 'fa' ? 'کاربر حذف شد' : 'User deleted');
      } catch (e) { this.toast(e.message); }
    },
    async createDept() {
      const name = (this.newDeptName || '').trim();
      if (name.length < 2) { this.toast(this.locale === 'fa' ? 'نام دپارتمان حداقل ۲ کاراکتر' : 'Department name must be at least 2 characters'); return; }
      try {
        const dept = await this.api('/api/departments', { method: 'POST', body: { name } });
        if (dept && dept.id) {
          this.departments.push(dept);
        } else {
          this.departments.push({ name });
        }
        this.showCreateDept = false; this.newDeptName = '';
        this.toast(this.locale === 'fa' ? 'دپارتمان ایجاد شد' : 'Department created');
      } catch (e) { this.toast(e.message); }
    },
    async deleteDept(d) {
      if (!d) return;
      const deptId = typeof d === 'object' ? d.id : d;
      try {
        await this.api('/api/departments/' + deptId, { method: 'DELETE' });
        this.departments = this.departments.filter(x => (typeof x === 'object' ? x.id : x) !== deptId);
      } catch (e) { this.toast(e.message); }
    },
    deptName(d) { return typeof d === 'object' ? d.name : d; },
    deptId(d) { return typeof d === 'object' ? d.id : d; },

    async createPoll() {
      if (!this.poll.question || !this.poll.question.trim() || !this.activeRoom) return;
      const opts = this.poll.options.filter(o => o && o.trim());
      if (opts.length < 2) { this.toast(this.locale === 'fa' ? 'حداقل ۲ گزینه لازم است' : 'At least 2 options required'); return; }
      try {
        const msg = await this.api('/api/messages/' + this.activeRoom.id, {
          method: 'POST',
          body: { text: '📊 ' + this.poll.question.trim() + '\n' + opts.map((o,i)=>`${i+1}. ${o.trim()}`).join('  '), poll: { question: this.poll.question.trim(), options: opts.map(o => o.trim()) } }
        });
        this.messagesByRoom[this.activeRoom.id] = this.messagesByRoom[this.activeRoom.id] || [];
        this.messagesByRoom[this.activeRoom.id].push({
          ...msg, time: jTime(msg.created_at), date: faDate(msg.created_at), mine: true, reactions: []
        });
        this.showPoll = false; this.poll = { question: '', options: ['', ''] };
        this.$nextTick(this.scrollToBottom);
      } catch (e) { this.toast(e.message); }
    },

    async createBackup() {
      try {
        await this.api('/api/settings/backup', { method: 'POST' });
        this.toast(this.locale === 'fa' ? 'بکاپ فوری ایجاد شد' : 'Backup created');
        this.loadBackups();
      } catch (e) { this.toast(e.message); }
    },
    async loadBackups() {
      try {
        this.backups = await this.api('/api/settings/backups') || [];
      } catch (e) { console.error('loadBackups:', e); }
    },
    // BUG FIX #11: saveCompany properly saves and shows feedback
    async saveCompany() {
      try {
        await this.api('/api/settings/company', { method: 'POST', body: { company_name: (this.company.name || '').trim() } });
        this.toast(this.t('saved'));
      } catch (e) { this.toast(e.message); }
    },

    // ============ WEBSOCKET ============
    // BUG FIX: encodeURIComponent token + prevent duplicate connections
    connectWS() {
      if (!this.token) return;
      if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) return;
      clearTimeout(this._wsReconnectTimer);
      const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
      this.ws = new WebSocket(`${proto}//${location.host}/ws?token=${encodeURIComponent(this.token)}`);
      this.ws.onmessage = (ev) => {
        try {
          const msg = JSON.parse(ev.data);
          this.handleWS(msg);
        } catch (e) { console.error('WS parse:', e); }
      };
      this.ws.onclose = () => {
        if (this.token) this._wsReconnectTimer = setTimeout(() => this.connectWS(), 5000);
      };
      this.ws.onerror = () => {};
    },

    // BUG FIX: handleWS validates room_id/user_id before use
    handleWS(msg) {
      if (!msg || !msg.type) return;
      switch (msg.type) {
        case 'new_message': {
          if (!msg.room_id) break;
          if (msg.room_id === this.activeRoomId) {
            this.messagesByRoom[msg.room_id] = this.messagesByRoom[msg.room_id] || [];
            this.messagesByRoom[msg.room_id].push({
              ...msg, time: jTime(msg.created_at), date: faDate(msg.created_at),
              mine: msg.sender_id === this.currentUser?.id, reactions: []
            });
            this.$nextTick(this.scrollToBottom);
          } else {
            const room = this.rooms.find(r => r.id === msg.room_id);
            if (room) { room.unread = (room.unread || 0) + 1; this.unreadMap[msg.room_id] = room.unread; localStorage.setItem('khan_readmap', JSON.stringify(this.unreadMap)); }
          }
          break;
        }
        case 'user_typing':
          if (msg.room_id && msg.room_id === this.activeRoomId && this.activeRoom) this.activeRoom.typingUser = msg.user_name;
          break;
        case 'user_stop_typing':
          if (msg.room_id && msg.room_id === this.activeRoomId && this.activeRoom) this.activeRoom.typingUser = null;
          break;
        case 'message_read':
          if (msg.room_id && msg.room_id === this.activeRoomId) {
            const arr = this.messagesByRoom[msg.room_id];
            if (Array.isArray(arr)) arr.forEach(m => { if (m.id <= msg.last_id) m.read = true; });
          }
          break;
        case 'reaction': {
          if (!msg.room_id || !msg.message_id) break;
          const roomMsgs = this.messagesByRoom[msg.room_id];
          if (Array.isArray(roomMsgs)) {
            const m = roomMsgs.find(x => x.id === msg.message_id);
            if (m) {
              m.reactions = m.reactions || [];
              let rx = m.reactions.find(r => r.emoji === msg.emoji);
              if (rx) { rx.count = msg.count; rx.byMe = msg.by_me; }
              else m.reactions.push({ emoji: msg.emoji, count: msg.count, byMe: msg.by_me });
            }
          }
          break;
        }
        case 'user_online': {
          if (!msg.user_id) break;
          const u = this.users.find(x => x.id === msg.user_id); if (u) u.online = true;
          break;
        }
        case 'user_offline': {
          if (!msg.user_id) break;
          const u2 = this.users.find(x => x.id === msg.user_id); if (u2) u2.online = false;
          break;
        }
      }
    },

    mounted() {
      document.documentElement.setAttribute('dir', this.dir);
      document.documentElement.setAttribute('lang', this.locale);
      document.documentElement.setAttribute('data-theme', this.themeColor + '-' + this.themeMode);
      window.addEventListener('resize', () => { this.isMobile = window.innerWidth < 768; if (!this.isMobile) this.sidebarOpen = true; });
      window.addEventListener('click', (e) => { if (this.ctxMenu.show && !e.target.closest('.context-menu')) this.ctxMenu.show = false; });
      this.loadSession();
      this.api('/api/setup/needs-setup').then(res => { this.needsSetup = res.needs_setup; }).catch(() => {});
    },
  },
}).mount('#app');
