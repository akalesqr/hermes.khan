package database

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	_ "modernc.org/sqlite"
)

// SQLiteDB wraps *sql.DB with helper methods for Khan v1.1
type SQLiteDB struct {
	*sql.DB
}

// OpenSQLite opens a SQLite database with WAL mode and foreign keys enabled
func OpenSQLite(path string) (*SQLiteDB, error) {
	dsn := path + "?_journal_mode=WAL&_busy_timeout=5000&_foreign_keys=ON&_synchronous=NORMAL&_cache_size=-8000&_temp_store=MEMORY"
	db, err := sql.Open("sqlite", dsn)
	if err != nil {
		return nil, fmt.Errorf("open sqlite: %w", err)
	}
	db.SetMaxOpenConns(1) // SQLite = single writer
	db.SetMaxIdleConns(1)
	db.SetConnMaxLifetime(0)

	if err := db.Ping(); err != nil {
		db.Close()
		return nil, fmt.Errorf("ping sqlite: %w", err)
	}
	return &SQLiteDB{db}, nil
}

// RunMigrations applies the embedded SQL migrations
func (db *SQLiteDB) RunMigrations() error {
	if _, err := db.Exec(migrationUp); err != nil {
		return fmt.Errorf("run migration: %w", err)
	}
	log.Println("✅ SQLite migrations applied")
	return nil
}

// MigrateJSONToSQLite reads all JSON files and inserts into SQLite
// Only runs if the users table is empty (first run detection)
func (db *SQLiteDB) MigrateJSONToSQLite(jsonDir string) error {
	// Check if already migrated
	var count int
	if err := db.QueryRow("SELECT COUNT(*) FROM users").Scan(&count); err != nil {
		return fmt.Errorf("check users count: %w", err)
	}
	if count > 0 {
		log.Println("ℹ️  SQLite already has data, skipping JSON migration")
		return nil
	}

	data := &Data{
		Seq:         map[string]int64{},
		Users:       []UserRecord{},
		Rooms:       []RoomRecord{},
		RoomMembers: []RoomMemberRecord{},
		Messages:    []MessageRecord{},
		Reactions:   []ReactionRecord{},
		Sessions:    []SessionRecord{},
		Files:       []FileRecord{},
		Reads:       []ReadRecord{},
		Polls:       []PollRecord{},
		PollVotes:   []PollVoteRecord{},
		Invites:     []InviteRecord{},
		Pins:        []PinRecord{},
		Departments: []DepartmentRecord{},
	}

	// Load each JSON file
	for table, fname := range tableFiles {
		raw, err := os.ReadFile(filepath.Join(jsonDir, fname))
		if err != nil {
			if os.IsNotExist(err) {
				continue
			}
			log.Printf("⚠️  skip %s: %v", fname, err)
			continue
		}
		if len(raw) < 3 { // "[]" or "{}"
			continue
		}
		if err := json.Unmarshal(raw, tablePtr(data, table)); err != nil {
			log.Printf("⚠️  corrupt %s: %v", fname, err)
			continue
		}
	}

	// Load seq.json
	if raw, err := os.ReadFile(filepath.Join(jsonDir, "seq.json")); err == nil {
		var seq map[string]int64
		if err := json.Unmarshal(raw, &seq); err == nil && seq != nil {
			data.Seq = seq
		}
	}

	// Insert everything in a transaction
	tx, err := db.Begin()
	if err != nil {
		return fmt.Errorf("begin migration tx: %w", err)
	}
	defer tx.Rollback()

	// Migrate users
	for _, u := range data.Users {
		if _, err := tx.Exec(
			`INSERT INTO users (id,username,password_hash,display_name,avatar_path,role,hidden,active,must_change_pwd,created_at,last_seen,status,status_text)
			 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
			u.ID, u.Username, u.PasswordHash, u.DisplayName, u.AvatarPath, u.Role,
			boolToInt(u.Hidden), boolToInt(u.Active), boolToInt(u.MustChangePwd),
			u.CreatedAt, u.LastSeen, u.Status, u.StatusText,
		); err != nil {
			return fmt.Errorf("insert user %s: %w", u.Username, err)
		}
	}

	// Migrate departments
	for _, d := range data.Departments {
		if _, err := tx.Exec(`INSERT INTO departments (id,name,created_at) VALUES (?,?,?)`,
			d.ID, d.Name, d.CreatedAt); err != nil {
			return fmt.Errorf("insert dept: %w", err)
		}
	}

	// Migrate rooms
	for _, r := range data.Rooms {
		if _, err := tx.Exec(
			`INSERT INTO rooms (id,name,type,creator_id,created_at,department,topic,description,avatar,archived)
			 VALUES (?,?,?,?,?,?,?,?,?,?)`,
			r.ID, r.Name, r.Type, r.CreatorID, r.CreatedAt, r.Department,
			r.Topic, r.Description, r.Avatar, boolToInt(r.Archived),
		); err != nil {
			return fmt.Errorf("insert room %s: %w", r.Name, err)
		}
	}

	// Migrate room_members
	for _, rm := range data.RoomMembers {
		if _, err := tx.Exec(
			`INSERT INTO room_members (id,room_id,user_id,role,joined_at) VALUES (?,?,?,?,?)`,
			rm.ID, rm.RoomID, rm.UserID, rm.Role, rm.JoinedAt,
		); err != nil {
			return fmt.Errorf("insert room_member: %w", err)
		}
	}

	// Migrate messages
	for _, m := range data.Messages {
		mentionsJSON, _ := json.Marshal(m.Mentions)
		if _, err := tx.Exec(
			`INSERT INTO messages (id,room_id,sender_id,body,file_id,created_at,edited_at,deleted_at,reply_to,forwarded_from,mentions,urgent,poll_id,attachment)
			 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
			m.ID, m.RoomID, m.SenderID, m.Body, m.FileID, m.CreatedAt,
			m.EditedAt, m.DeletedAt, m.ReplyTo, m.Forwarded,
			string(mentionsJSON), boolToInt(m.Urgent), m.PollID, m.Attachment,
		); err != nil {
			return fmt.Errorf("insert msg %d: %w", m.ID, err)
		}
	}

	// Migrate reactions
	for _, r := range data.Reactions {
		if _, err := tx.Exec(
			`INSERT INTO reactions (id,message_id,user_id,emoji) VALUES (?,?,?,?)`,
			r.ID, r.MessageID, r.UserID, r.Emoji,
		); err != nil {
			return fmt.Errorf("insert reaction: %w", err)
		}
	}

	// Migrate sessions
	for _, s := range data.Sessions {
		if _, err := tx.Exec(
			`INSERT INTO sessions (id,user_id,token,expires_at,created_at) VALUES (?,?,?,?,?)`,
			s.ID, s.UserID, s.Token, s.ExpiresAt, s.CreatedAt,
		); err != nil {
			return fmt.Errorf("insert session: %w", err)
		}
	}

	// Migrate files
	for _, f := range data.Files {
		if _, err := tx.Exec(
			`INSERT INTO files (id,owner_id,room_id,file_name,stored_as,size,mime_type,created_at) VALUES (?,?,?,?,?,?,?,?)`,
			f.ID, f.OwnerID, f.RoomID, f.FileName, f.StoredAs, f.Size, f.MimeType, f.CreatedAt,
		); err != nil {
			return fmt.Errorf("insert file: %w", err)
		}
	}

	// Migrate reads
	for _, r := range data.Reads {
		if _, err := tx.Exec(
			`INSERT INTO reads (id,room_id,user_id,last_read,updated_at) VALUES (?,?,?,?,?)`,
			r.ID, r.RoomID, r.UserID, r.LastRead, r.UpdatedAt,
		); err != nil {
			return fmt.Errorf("insert read: %w", err)
		}
	}

	// Migrate polls
	for _, p := range data.Polls {
		optionsJSON, _ := json.Marshal(p.Options)
		if _, err := tx.Exec(
			`INSERT INTO polls (id,room_id,creator_id,question,options,created_at,closed,closed_at) VALUES (?,?,?,?,?,?,?,?)`,
			p.ID, p.RoomID, p.CreatorID, p.Question, string(optionsJSON),
			p.CreatedAt, boolToInt(p.Closed), p.ClosedAt,
		); err != nil {
			return fmt.Errorf("insert poll: %w", err)
		}
	}

	// Migrate poll_votes
	for _, pv := range data.PollVotes {
		if _, err := tx.Exec(
			`INSERT INTO poll_votes (id,poll_id,user_id,option,voted_at) VALUES (?,?,?,?,?)`,
			pv.ID, pv.PollID, pv.UserID, pv.Option, pv.VotedAt,
		); err != nil {
			return fmt.Errorf("insert poll_vote: %w", err)
		}
	}

	// Migrate invites
	for _, inv := range data.Invites {
		if _, err := tx.Exec(
			`INSERT INTO invites (id,room_id,user_id,by_user_id,created_at) VALUES (?,?,?,?,?)`,
			inv.ID, inv.RoomID, inv.UserID, inv.ByUserID, inv.CreatedAt,
		); err != nil {
			return fmt.Errorf("insert invite: %w", err)
		}
	}

	// Migrate pins
	for _, p := range data.Pins {
		if _, err := tx.Exec(
			`INSERT INTO pins (id,room_id,message_id,user_id,created_at) VALUES (?,?,?,?,?)`,
			p.ID, p.RoomID, p.MessageID, p.UserID, p.CreatedAt,
		); err != nil {
			return fmt.Errorf("insert pin: %w", err)
		}
	}

	// Update sequence counters
	for table, seq := range data.Seq {
		if _, err := tx.Exec(
			`UPDATE sqlite_sequence SET seq=? WHERE name=?`, seq, table,
		); err != nil {
			// sqlite_sequence might not exist yet, ignore
		}
	}

	if err := tx.Commit(); err != nil {
		return fmt.Errorf("commit migration: %w", err)
	}

	total := len(data.Users) + len(data.Rooms) + len(data.Messages) + len(data.Sessions)
	log.Printf("✅ JSON → SQLite migration complete: %d records", total)
	return nil
}

// Backup copies the SQLite database file to a timestamped backup
func (db *SQLiteDB) Backup(destDir string) (string, error) {
	if err := os.MkdirAll(destDir, 0o755); err != nil {
		return "", fmt.Errorf("create backup dir: %w", err)
	}
	sub := filepath.Join(destDir, fmt.Sprintf("khan-backup-%s", time.Now().Format("20060102-150405")))
	if err := os.MkdirAll(sub, 0o755); err != nil {
		return "", err
	}
	// Use SQLite VACUUM INTO for atomic backup
	if _, err := db.Exec(fmt.Sprintf("VACUUM INTO '%s/khan.db'", sub)); err != nil {
		return "", fmt.Errorf("vacuum backup: %w", err)
	}
	return sub, nil
}

// helpers

func boolToInt(b bool) int {
	if b {
		return 1
	}
	return 0
}

func intToBool(i int) bool {
	return i != 0
}

// queryCount is a helper to check table row counts
func (db *SQLiteDB) queryCount(table string) (int, error) {
	var n int
	err := db.QueryRow(fmt.Sprintf("SELECT COUNT(*) FROM %s", table)).Scan(&n)
	return n, err
}

// CountUsers returns the number of non-hidden users (license check)
func (db *SQLiteDB) CountUsers() (int, error) {
	var n int
	err := db.QueryRow("SELECT COUNT(*) FROM users WHERE hidden = 0").Scan(&n)
	return n, err
}

// nowStr is defined in store.go

// parseTime parses an RFC3339 string, returns empty string for empty input
func parseTime(s string) string {
	if s == "" {
		return ""
	}
	t, err := time.Parse(time.RFC3339, s)
	if err != nil {
		return s
	}
	return t.Format(time.RFC3339)
}

// parseInt64 safely parses a string to int64
func parseInt64(s string) int64 {
	n, _ := strconv.ParseInt(s, 10, 64)
	return n
}

// jsonIntArray marshals []int64 to JSON string
func jsonIntArray(ids []int64) string {
	if len(ids) == 0 {
		return "[]"
	}
	b, _ := json.Marshal(ids)
	return string(b)
}

// jsonStrArray marshals []string to JSON string
func jsonStrArray(ss []string) string {
	if len(ss) == 0 {
		return "[]"
	}
	b, _ := json.Marshal(ss)
	return string(b)
}

// parseJSONArrayInt64 parses a JSON array string to []int64
func parseJSONArrayInt64(s string) []int64 {
	if s == "" || s == "[]" || s == "null" {
		return nil
	}
	var ids []int64
	if err := json.Unmarshal([]byte(s), &ids); err != nil {
		return nil
	}
	return ids
}

// parseJSONStrArray parses a JSON array string to []string
func parseJSONStrArray(s string) []string {
	if s == "" || s == "[]" || s == "null" {
		return nil
	}
	var ss []string
	if err := json.Unmarshal([]byte(s), &ss); err != nil {
		return nil
	}
	return ss
}

// sqlStr returns a string suitable for SQL, defaulting to ""
func sqlStr(s string) string {
	return strings.TrimSpace(s)
}
