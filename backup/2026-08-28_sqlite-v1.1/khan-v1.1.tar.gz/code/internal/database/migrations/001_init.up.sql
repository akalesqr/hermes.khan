-- Khan v1.1 — SQLite schema
-- All timestamps stored as RFC3339 strings (compatible with existing JSON data)

PRAGMA journal_mode = WAL;
PRAGMA busy_timeout = 5000;
PRAGMA foreign_keys = ON;

-- ═══════════════════════════════════════════
-- USERS
-- ═══════════════════════════════════════════
CREATE TABLE IF NOT EXISTS users (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    username        TEXT    NOT NULL UNIQUE,
    password_hash   TEXT    NOT NULL DEFAULT '',
    display_name    TEXT    NOT NULL DEFAULT '',
    avatar_path     TEXT    NOT NULL DEFAULT '',
    role            TEXT    NOT NULL DEFAULT 'user',     -- user | sup | adm | sadm
    hidden          INTEGER NOT NULL DEFAULT 0,          -- boolean: 0=false, 1=true
    active          INTEGER NOT NULL DEFAULT 1,          -- boolean
    must_change_pwd INTEGER NOT NULL DEFAULT 0,          -- boolean
    created_at      TEXT    NOT NULL DEFAULT '',
    last_seen       TEXT    NOT NULL DEFAULT '',
    status          TEXT    NOT NULL DEFAULT '',          -- online | offline | away
    status_text     TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_users_username   ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_role       ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_hidden     ON users(hidden);

-- ═══════════════════════════════════════════
-- ROOMS
-- ═══════════════════════════════════════════
CREATE TABLE IF NOT EXISTS rooms (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL DEFAULT '',
    type        TEXT    NOT NULL DEFAULT 'group',         -- dm | group | public | private | channel
    creator_id  INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT    NOT NULL DEFAULT '',
    department  INTEGER NOT NULL DEFAULT 0,               -- 0 = none
    topic       TEXT    NOT NULL DEFAULT '',
    description TEXT    NOT NULL DEFAULT '',
    avatar      TEXT    NOT NULL DEFAULT '',
    archived    INTEGER NOT NULL DEFAULT 0                -- boolean
);
CREATE INDEX IF NOT EXISTS idx_rooms_type       ON rooms(type);
CREATE INDEX IF NOT EXISTS idx_rooms_creator    ON rooms(creator_id);
CREATE INDEX IF NOT EXISTS idx_rooms_department ON rooms(department);

-- ═══════════════════════════════════════════
-- ROOM MEMBERS
-- ═══════════════════════════════════════════
CREATE TABLE IF NOT EXISTS room_members (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id   INTEGER NOT NULL,
    user_id   INTEGER NOT NULL,
    role      TEXT    NOT NULL DEFAULT 'member',          -- owner | admin | member
    joined_at TEXT    NOT NULL DEFAULT '',
    UNIQUE(room_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_rm_room ON room_members(room_id);
CREATE INDEX IF NOT EXISTS idx_rm_user ON room_members(user_id);

-- ═══════════════════════════════════════════
-- MESSAGES (largest table — most indexes)
-- ═══════════════════════════════════════════
CREATE TABLE IF NOT EXISTS messages (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id       INTEGER NOT NULL,
    sender_id     INTEGER NOT NULL DEFAULT 0,            -- -1 = deleted user
    body          TEXT    NOT NULL DEFAULT '',             -- base64 AES-GCM
    file_id       INTEGER,                               -- NULL if no attachment
    created_at    TEXT    NOT NULL DEFAULT '',
    edited_at     TEXT    NOT NULL DEFAULT '',
    deleted_at    TEXT    NOT NULL DEFAULT '',
    reply_to      INTEGER,                               -- NULL if not a reply
    forwarded_from INTEGER,                              -- original message id
    mentions      TEXT    NOT NULL DEFAULT '[]',          -- JSON array of user ids
    urgent        INTEGER NOT NULL DEFAULT 0,             -- boolean
    poll_id       INTEGER,                               -- NULL if not a poll
    attachment    TEXT    NOT NULL DEFAULT ''              -- sticker/emoji
);
CREATE INDEX IF NOT EXISTS idx_msg_room    ON messages(room_id, created_at);
CREATE INDEX IF NOT EXISTS idx_msg_sender  ON messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_msg_reply   ON messages(reply_to);
CREATE INDEX IF NOT EXISTS idx_msg_file    ON messages(file_id);

-- ═══════════════════════════════════════════
-- REACTIONS
-- ═══════════════════════════════════════════
CREATE TABLE IF NOT EXISTS reactions (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id INTEGER NOT NULL,
    user_id    INTEGER NOT NULL,
    emoji      TEXT    NOT NULL DEFAULT '',
    UNIQUE(message_id, user_id, emoji)
);
CREATE INDEX IF NOT EXISTS idx_rx_message ON reactions(message_id);

-- ═══════════════════════════════════════════
-- SESSIONS
-- ═══════════════════════════════════════════
CREATE TABLE IF NOT EXISTS sessions (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    token      TEXT    NOT NULL UNIQUE,
    expires_at TEXT    NOT NULL DEFAULT '',
    created_at TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_sess_token  ON sessions(token);
CREATE INDEX IF NOT EXISTS idx_sess_user   ON sessions(user_id);

-- ═══════════════════════════════════════════
-- FILES
-- ═══════════════════════════════════════════
CREATE TABLE IF NOT EXISTS files (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id   INTEGER NOT NULL,
    room_id    INTEGER NOT NULL,
    file_name  TEXT    NOT NULL DEFAULT '',
    stored_as  TEXT    NOT NULL DEFAULT '',
    size       INTEGER NOT NULL DEFAULT 0,
    mime_type  TEXT    NOT NULL DEFAULT '',
    created_at TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_files_owner ON files(owner_id);
CREATE INDEX IF NOT EXISTS idx_files_room  ON files(room_id);

-- ═══════════════════════════════════════════
-- READS (read receipts)
-- ═══════════════════════════════════════════
CREATE TABLE IF NOT EXISTS reads (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id    INTEGER NOT NULL,
    user_id    INTEGER NOT NULL,
    last_read  INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT    NOT NULL DEFAULT '',
    UNIQUE(room_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_reads_room ON reads(room_id);

-- ═══════════════════════════════════════════
-- POLLS
-- ═══════════════════════════════════════════
CREATE TABLE IF NOT EXISTS polls (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id    INTEGER NOT NULL,
    creator_id INTEGER NOT NULL,
    question   TEXT    NOT NULL DEFAULT '',
    options    TEXT    NOT NULL DEFAULT '[]',             -- JSON array of strings
    created_at TEXT    NOT NULL DEFAULT '',
    closed     INTEGER NOT NULL DEFAULT 0,
    closed_at  TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_polls_room ON polls(room_id);

-- ═══════════════════════════════════════════
-- POLL VOTES
-- ═══════════════════════════════════════════
CREATE TABLE IF NOT EXISTS poll_votes (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    poll_id  INTEGER NOT NULL,
    user_id  INTEGER NOT NULL,
    option   INTEGER NOT NULL DEFAULT 0,
    voted_at TEXT    NOT NULL DEFAULT '',
    UNIQUE(poll_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_pv_poll ON poll_votes(poll_id);

-- ═══════════════════════════════════════════
-- INVITES
-- ═══════════════════════════════════════════
CREATE TABLE IF NOT EXISTS invites (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id    INTEGER NOT NULL,
    user_id    INTEGER NOT NULL,
    by_user_id INTEGER NOT NULL,
    created_at TEXT    NOT NULL DEFAULT '',
    UNIQUE(room_id, user_id)
);

-- ═══════════════════════════════════════════
-- PINS
-- ═══════════════════════════════════════════
CREATE TABLE IF NOT EXISTS pins (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id    INTEGER NOT NULL,
    message_id INTEGER NOT NULL,
    user_id    INTEGER NOT NULL,
    created_at TEXT    NOT NULL DEFAULT '',
    UNIQUE(room_id, message_id)
);

-- ═══════════════════════════════════════════
-- DEPARTMENTS
-- ═══════════════════════════════════════════
CREATE TABLE IF NOT EXISTS departments (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT    NOT NULL DEFAULT '',
    created_at TEXT    NOT NULL DEFAULT ''
);

-- ═══════════════════════════════════════════
-- SCHEMA VERSION (for golang-migrate)
-- ═══════════════════════════════════════════
CREATE TABLE IF NOT EXISTS schema_migrations (
    version INTEGER PRIMARY KEY,
    dirty   INTEGER NOT NULL DEFAULT 0
);
INSERT INTO schema_migrations (version, dirty) VALUES (1, 0);
